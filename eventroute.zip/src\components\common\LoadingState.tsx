import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingStateProps {
  message?: string;
  subtext?: string;
}

export const LoadingState: React.FC<LoadingStateProps> = ({
  message = 'Calculating routes and event feasibility...',
  subtext = 'Optimizing departure buffers and checking transit options',
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center my-8">
      <div className="relative mb-4">
        <div className="w-14 h-14 rounded-full border-4 border-brand-100 border-t-brand-600 animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-6 h-6 text-brand-600 animate-pulse" />
        </div>
      </div>
      <h3 className="text-base font-semibold text-slate-800 mb-1">{message}</h3>
      <p className="text-xs text-slate-500 max-w-sm">{subtext}</p>
    </div>
  );
};
