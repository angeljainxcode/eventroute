import React from 'react';
import { CollegeEvent } from '../../types/event';
import { FeasibilityResult } from '../../types/feasibility';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { formatDuration } from '../../services/feasibilityEngine';
import { 
  X, 
  MapPin, 
  Calendar, 
  Clock, 
  IndianRupee, 
  Users, 
  Bookmark, 
  BookmarkCheck, 
  ExternalLink, 
  ShieldCheck, 
  Route, 
  CheckCircle2, 
  Compass, 
  AlertCircle
} from 'lucide-react';

interface EventDetailsModalProps {
  event: CollegeEvent | null;
  feasibility: FeasibilityResult | null;
  isOpen: boolean;
  isSaved: boolean;
  onClose: () => void;
  onToggleSave: () => void;
  onOpenFeasibility: (event: CollegeEvent) => void;
}

export const EventDetailsModal: React.FC<EventDetailsModalProps> = ({
  event,
  feasibility,
  isOpen,
  isSaved,
  onClose,
  onToggleSave,
  onOpenFeasibility,
}) => {
  if (!isOpen || !event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-100 w-full max-w-2xl overflow-hidden flex flex-col max-h-[92vh] animate-scaleUp"
        role="dialog"
      >
        {/* Banner with floating tags */}
        <div className="relative h-48 sm:h-56 w-full bg-slate-900 overflow-hidden">
          <img
            src={event.bannerUrl}
            alt={event.title}
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md transition-colors"
          >
            <X size={18} />
          </button>

          {/* Category & Fee Pill */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white font-bold text-xs">
              {event.category}
            </span>
            <span className="px-3 py-1 rounded-full bg-emerald-500/90 backdrop-blur-md text-white font-bold text-xs">
              {event.registrationFee === 0 ? 'Free Entry' : `₹${event.registrationFee} Registration`}
            </span>
          </div>

          {/* Bottom Title inside Banner */}
          <div className="absolute bottom-4 left-4 right-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white leading-tight">
              {event.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 flex items-center gap-1.5">
              <MapPin size={14} className="text-brand-400 shrink-0" />
              <span>{event.hostCollege} • {event.city}</span>
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">

          {/* Quick Feasibility summary strip if available */}
          {feasibility && (
            <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              feasibility.verdict === 'FEASIBLE'
                ? 'bg-emerald-50/70 border-emerald-200'
                : feasibility.verdict === 'DIFFICULT'
                ? 'bg-amber-50/70 border-amber-200'
                : 'bg-rose-50/70 border-rose-200'
            }`}>
              <div className="flex items-center gap-3">
                <FeasibilityBadge verdict={feasibility.verdict} size="md" />
                <div>
                  <div className="text-xs font-bold text-slate-900">
                    Must depart by {feasibility.requiredDepartureTime}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {feasibility.distanceKm} km away • {formatDuration(feasibility.travelDurationMinutes)} travel time
                  </div>
                </div>
              </div>

              <button
                onClick={() => onOpenFeasibility(event)}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors shrink-0 shadow-xs"
              >
                <Route size={14} />
                <span>Full Feasibility Dashboard</span>
              </button>
            </div>
          )}

          {/* Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <span className="text-[11px] font-semibold text-slate-400 block mb-0.5">Event Date</span>
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                <Calendar size={13} className="text-brand-600" />
                {event.date}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <span className="text-[11px] font-semibold text-slate-400 block mb-0.5">Session Timings</span>
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                <Clock size={13} className="text-indigo-600" />
                {event.startTime} - {event.endTime}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <span className="text-[11px] font-semibold text-slate-400 block mb-0.5">Eligibility</span>
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1 truncate">
                <Users size={13} className="text-emerald-600" />
                {event.eligibility}
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">About the Event</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              {event.description}
            </p>
          </div>

          {/* Venue & Location details */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <h4 className="text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
              <MapPin size={14} className="text-brand-600" />
              Venue & Location
            </h4>
            <p className="text-xs text-slate-600">{event.venue}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Coordinates: {event.coordinates.lat.toFixed(4)}, {event.coordinates.lng.toFixed(4)}</p>
          </div>

          {/* Source & Trust Verification */}
          <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-100 flex items-start gap-2.5">
            <ShieldCheck size={16} className="text-brand-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <span className="font-bold text-slate-800">Source & Data Verification</span>
              <p className="text-slate-500 mt-0.5 leading-normal">
                {event.source} • Last verified: {new Date(event.lastVerified).toLocaleDateString()}
              </p>
              {event.isDemo && (
                <p className="text-[10px] text-amber-700 font-medium mt-1">
                  * Notice: This is clearly labelled demonstration data for prototype verification.
                </p>
              )}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onToggleSave}
            className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              isSaved
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            {isSaved ? <BookmarkCheck size={15} /> : <Bookmark size={15} />}
            <span>{isSaved ? 'Saved' : 'Save Event'}</span>
          </button>

          <div className="flex items-center gap-2">
            <a
              href={event.registrationUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold text-slate-700 transition-colors"
            >
              <span>Demo Registration</span>
              <ExternalLink size={13} />
            </a>

            <button
              type="button"
              onClick={() => onOpenFeasibility(event)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all"
            >
              <Route size={15} />
              <span>Check Route & Feasibility</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
