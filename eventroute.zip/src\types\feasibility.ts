import { TravelMode } from './location';
import { TransitOption } from './event';

export type FeasibilityVerdict = 'FEASIBLE' | 'DIFFICULT' | 'NOT_FEASIBLE';

export type ReturnStatus = 'CONFIRMED' | 'UNKNOWN' | 'NO_VIABLE_RETURN';

export interface FeasibilityConfig {
  arrivalBufferMinutes: number;         // Buffer desired between arrival at venue and event start (default: 30)
  postEventDepartureBufferMinutes: number; // Buffer desired between event end and transit departure (default: 30)
  maxBudget: number;                   // In INR
  travelMode: TravelMode;
  allowOvernightReturn?: boolean;
}

export interface FeasibilityVerdictBreakdown {
  timelineOk: boolean;
  budgetOk: boolean;
  returnOk: boolean;
  arrivalMarginMinutes: number;        // positive = arrives before start, negative = arrives late
  budgetMarginRupees: number;          // positive = under budget, negative = over budget
  returnMarginMinutes?: number;        // time between event end and return departure
}

export interface FeasibilityResult {
  verdict: FeasibilityVerdict;
  verdictTitle: string;
  verdictSummary: string;
  
  // Distances and durations
  distanceKm: number;
  travelDurationMinutes: number;
  
  // Cost breakdown
  estimatedOneWayCost: number;
  estimatedRoundTripCost: number;
  totalTripEstimatedCost: number; // travel + registrationFee
  budgetExceeded: boolean;
  
  // Timing calculations
  requiredDepartureTime: string;       // "05:40 AM" (or 24h format)
  expectedArrivalTime: string;         // "09:12 AM"
  eventStartTime: string;              // "10:00 AM"
  eventEndTime: string;                // "05:00 PM"
  availableTimeAtEventMinutes: number; // e.g. 420 mins (7 hours)
  arrivalBufferMinutes: number;        // e.g. 48 mins
  lateArrival: boolean;
  lateArrivalMinutes: number;          // 0 if on time
  
  // Return trip analysis
  returnStatus: ReturnStatus;
  lastViableReturnDeparture: string | null;  // e.g. "06:15 PM" or null
  expectedHomeArrival: string | null;        // e.g. "09:47 PM"
  returnTripDurationMinutes: number;
  matchingReturnTransit?: TransitOption | null;
  allReturnOptions?: TransitOption[];
  
  // Explanations, alerts, and suggestions
  breakdown: FeasibilityVerdictBreakdown;
  reasons: string[];
  warnings: string[];
  suggestions: string[];
  
  // Metadata
  isEstimatedTransit: boolean;
  isScenarioCalibrated: boolean;
}
