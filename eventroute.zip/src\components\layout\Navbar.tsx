import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  MapPin, 
  Route, 
  Bookmark, 
  PlusCircle, 
  Sparkles, 
  Compass, 
  Menu, 
  X, 
  Database,
  IndianRupee
} from 'lucide-react';

interface NavbarProps {
  currentView: 'landing' | 'discovery' | 'saved' | 'publish';
  onNavigate: (view: 'landing' | 'discovery' | 'saved' | 'publish') => void;
  onOpenLocationModal: () => void;
  onOpenAiModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenLocationModal,
  onOpenAiModal,
}) => {
  const { origin, preferences, savedEventIds, dataSource } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-2.5 cursor-pointer group shrink-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-700 via-brand-600 to-blue-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
            <Route size={20} strokeWidth={2.5} />
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-slate-900 group-hover:text-brand-600 transition-colors">
              EventRoute
            </span>
            <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest text-brand-600 block leading-none">
              Feasibility First
            </span>
          </div>
        </div>

        {/* Center Nav Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-1 text-xs font-bold text-slate-600">
          <button
            onClick={() => onNavigate('landing')}
            className={`px-3 py-2 rounded-xl transition-colors ${
              currentView === 'landing' ? 'text-brand-700 bg-brand-50' : 'hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Overview
          </button>

          <button
            onClick={() => onNavigate('discovery')}
            className={`px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5 ${
              currentView === 'discovery' ? 'text-brand-700 bg-brand-50' : 'hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Compass size={14} />
            <span>Discover Events</span>
          </button>

          <button
            onClick={() => onNavigate('saved')}
            className={`px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5 ${
              currentView === 'saved' ? 'text-brand-700 bg-brand-50' : 'hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Bookmark size={14} />
            <span>Saved ({savedEventIds.length})</span>
          </button>

          <button
            onClick={() => onNavigate('publish')}
            className={`px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5 ${
              currentView === 'publish' ? 'text-brand-700 bg-brand-50' : 'hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <PlusCircle size={14} />
            <span>Publish Event</span>
          </button>

          <button
            onClick={onOpenAiModal}
            className="px-3 py-2 rounded-xl text-indigo-700 hover:bg-indigo-50 font-bold transition-colors flex items-center gap-1.5"
          >
            <Sparkles size={14} className="text-indigo-600" />
            <span>AI Assistant</span>
          </button>
        </nav>

        {/* Right Actions: Origin Selector & Location Pill */}
        <div className="flex items-center gap-2.5">
          
          {/* Origin Quick Pill */}
          <button
            type="button"
            onClick={onOpenLocationModal}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100/80 text-xs font-semibold text-slate-700 transition-all shadow-2xs"
            title="Change your starting origin college or budget"
          >
            <MapPin size={13} className="text-brand-600" />
            <span className="hidden sm:inline font-bold text-slate-900">{origin.shortName}</span>
            <span className="sm:hidden font-bold">{origin.shortName.slice(0, 8)}</span>
            <span className="text-[10px] text-slate-400 font-mono">₹{preferences.budget}</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden px-4 pt-2 pb-5 border-t border-slate-100 bg-white space-y-2 text-xs font-bold animate-fadeIn">
          <button
            onClick={() => {
              onNavigate('landing');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl hover:bg-slate-50 text-slate-700"
          >
            Overview
          </button>
          <button
            onClick={() => {
              onNavigate('discovery');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2"
          >
            <Compass size={14} className="text-brand-600" />
            <span>Discover Events & Map</span>
          </button>
          <button
            onClick={() => {
              onNavigate('saved');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2"
          >
            <Bookmark size={14} className="text-amber-600" />
            <span>Saved Events ({savedEventIds.length})</span>
          </button>
          <button
            onClick={() => {
              onNavigate('publish');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2"
          >
            <PlusCircle size={14} className="text-emerald-600" />
            <span>Publish an Event</span>
          </button>
          <button
            onClick={() => {
              onOpenAiModal();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl hover:bg-indigo-50 text-indigo-700 flex items-center gap-2"
          >
            <Sparkles size={14} className="text-indigo-600" />
            <span>AI Assistant (Poster OCR & NL Query)</span>
          </button>
        </div>
      )}
    </header>
  );
};
