import React from 'react';
import { useApp } from '../../context/AppContext';
import { CollegeEvent } from '../../types/event';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { 
  Route, 
  MapPin, 
  Clock, 
  IndianRupee, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  Compass, 
  ShieldCheck, 
  Layers,
  ChevronRight,
  TrendingUp,
  Award
} from 'lucide-react';

interface LandingPageProps {
  onExploreEvents: () => void;
  onPublishEvent: () => void;
  onSelectEvent: (event: CollegeEvent) => void;
  onCheckFeasibility: (event: CollegeEvent) => void;
  onOpenLocationModal: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onExploreEvents,
  onPublishEvent,
  onSelectEvent,
  onCheckFeasibility,
  onOpenLocationModal,
}) => {
  const { events, origin, preferences, getFeasibility } = useApp();

  // Featured benchmark events (first 3)
  const featuredEvents = events.slice(0, 3);

  return (
    <div className="space-y-16 py-6 pb-20">
      
      {/* 1. Hero Section */}
      <section className="relative px-4 sm:px-6 max-w-7xl mx-auto pt-6 pb-12 text-center lg:text-left">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline Pill */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50/90 border border-blue-200 shadow-2xs text-brand-700 text-xs font-bold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-brand-600 animate-ping" />
              <span>FEASIBILITY-FIRST INTER-COLLEGE EVENT DISCOVERY</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.1]">
              Find events you can <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-blue-600 to-indigo-600">
                actually attend.
              </span>
            </h1>

            {/* Supporting Tagline & Paragraph */}
            <p className="text-lg sm:text-xl font-medium text-slate-700 max-w-2xl leading-relaxed">
              “Don’t just discover an event. Know whether you can actually attend it.”
            </p>
            <p className="text-sm sm:text-base text-slate-500 max-w-2xl leading-relaxed">
              EventRoute combines inter-college hackathons, robotics cups, and tech symposiums with deadline-constrained, budget-aware travel feasibility, exact morning leave times, and return transit guarantees.
            </p>

            {/* Starting College Pill Indicator */}
            <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs inline-flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center font-bold">
                <MapPin size={16} />
              </div>
              <div className="text-left text-xs">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Current Demo Base</span>
                <span className="font-bold text-slate-900">{origin.name}</span>
              </div>
              <button
                type="button"
                onClick={onOpenLocationModal}
                className="text-[11px] font-bold text-brand-600 hover:text-brand-700 px-2.5 py-1 rounded-lg bg-brand-50 border border-brand-200 ml-2"
              >
                Change
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                type="button"
                onClick={onExploreEvents}
                className="px-7 py-3.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-extrabold text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-2"
              >
                <span>Explore Events & Routes</span>
                <ArrowRight size={16} />
              </button>

              <button
                type="button"
                onClick={onPublishEvent}
                className="px-7 py-3.5 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-sm shadow-xs transition-colors flex items-center gap-2"
              >
                <span>Publish an Event</span>
              </button>
            </div>

          </div>

          {/* Right Column: Visual Central Benchmark Scenario Showcase */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xl relative overflow-hidden space-y-5">
              
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Central Demo Scenario</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-brand-700">
                  ITM Gwalior → Morena (~60 km)
                </span>
              </div>

              {/* Sample Calculation Result Box */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 text-white space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-md">
                    Chambal Tech Symposium
                  </span>
                  <span className="text-xs font-black bg-white text-orange-950 px-2 py-0.5 rounded-md">
                    DIFFICULT
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-black/15 p-2 rounded-xl">
                    <span className="text-[10px] uppercase text-white/80 block">Must Leave Origin</span>
                    <strong className="text-base font-black font-mono">05:40 AM</strong>
                  </div>
                  <div className="bg-black/15 p-2 rounded-xl">
                    <span className="text-[10px] uppercase text-white/80 block">Arrival at Venue</span>
                    <strong className="text-base font-black font-mono">09:12 AM</strong>
                  </div>
                </div>

                <p className="text-[11px] text-white/90 leading-snug">
                  Calculated from 10:00 AM start, 3h 32m transit duration, ₹180 one-way cost, and 48m arrival buffer.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 text-xs text-slate-600 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span>Student Origin:</span>
                  <strong className="text-slate-800">ITM Gwalior (NH-75)</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>One-Way Travel Fare:</span>
                  <strong className="text-slate-800">₹180 (Roundtrip ₹360)</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>Return Availability:</span>
                  <span className="font-semibold text-amber-700">Unconfirmed (Verify at stand)</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  const chambal = events.find(e => e.id === 'chambal-symposium-2026');
                  if (chambal) onCheckFeasibility(chambal);
                }}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
              >
                <span>Inspect Feasibility Calculation</span>
                <ChevronRight size={14} />
              </button>

            </div>
          </div>

        </div>
      </section>

      {/* 2. Three Feasibility Verdicts Section */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Three Clear Feasibility Verdicts
          </h2>
          <p className="text-sm text-slate-500">
            Every event is evaluated against your college origin, travel duration, student budget, and verified return transit timetable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Verdict 1: Feasible */}
          <div className="bg-white rounded-3xl border border-emerald-200 p-6 shadow-xs hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700">Verdict 01</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">FEASIBLE</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Expected arrival is strictly on time before kickoff with adequate safety buffer, total travel cost is comfortably within your allocated budget, and reliable same-day return transit is confirmed.
            </p>
            <div className="p-3 bg-emerald-50 rounded-xl text-[11px] font-semibold text-emerald-800 border border-emerald-100">
              ✓ On-time arrival guaranteed<br />
              ✓ Within student travel budget<br />
              ✓ Confirmed return bus/train timetable
            </div>
          </div>

          {/* Verdict 2: Difficult */}
          <div className="bg-white rounded-3xl border border-amber-200 p-6 shadow-xs hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <AlertTriangle size={24} />
            </div>
            <div>
              <span className="text-xs font-extrabold uppercase tracking-wider text-amber-700">Verdict 02</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">DIFFICULT</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Attendance may be technically possible but requires an extremely early departure (e.g. 5:40 AM), operates on razor-thin transfer buffers, slightly exceeds preferred budget, or relies on uncertain return schedules.
            </p>
            <div className="p-3 bg-amber-50 rounded-xl text-[11px] font-semibold text-amber-800 border border-amber-100">
              ⚠ Requires very early morning departure<br />
              ⚠ Exceeds preferred cost margin<br />
              ⚠ Return transit schedule unconfirmed
            </div>
          </div>

          {/* Verdict 3: Not Feasible */}
          <div className="bg-white rounded-3xl border border-rose-200 p-6 shadow-xs hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center">
              <XCircle size={24} />
            </div>
            <div>
              <span className="text-xs font-extrabold uppercase tracking-wider text-rose-700">Verdict 03</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">NOT FEASIBLE</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Arrival would occur after the event kickoff, transit duration demands leaving previous day, budget is exceeded by over 50%, or no viable same-day return journey exists before midnight.
            </p>
            <div className="p-3 bg-rose-50 rounded-xl text-[11px] font-semibold text-rose-800 border border-rose-100">
              ✕ Late arrival after event start<br />
              ✕ No viable return journey available<br />
              ✕ Overnight accommodation required
            </div>
          </div>
        </div>
      </section>

      {/* 3. How It Works Section */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-8 sm:p-12 text-white shadow-xl space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-brand-400">
              The Engineering Engine
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold">
              How EventRoute Computes Your Feasibility
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Transparent, deterministic calculations instead of hallucinated advice.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                step: '01',
                title: 'Select Origin College',
                desc: 'Set ITM Gwalior, MITS, Jiwaji University, or your custom hostel as base.',
              },
              {
                step: '02',
                title: 'Calculate Departure',
                desc: 'Subtracts road travel time + configurable arrival safety buffer (e.g. 48 mins) from event kickoff.',
              },
              {
                step: '03',
                title: 'Verify Return Timetable',
                desc: 'Cross-checks event end time with scheduled bus & train departures to confirm return home.',
              },
              {
                step: '04',
                title: 'Budget Viability Check',
                desc: 'Validates two-way travel tickets + registration fee against your budget limit.',
              },
            ].map(item => (
              <div key={item.step} className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/10 space-y-2">
                <span className="text-brand-400 font-mono font-black text-xl">{item.step}</span>
                <h3 className="font-bold text-base text-white">{item.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Sample Upcoming Events Carousel/Grid */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900">
              Featured Regional College Events
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Sample inter-college hackathons and symposia in Gwalior and Central India
            </p>
          </div>

          <button
            type="button"
            onClick={onExploreEvents}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-brand-600 hover:text-brand-700 transition-colors"
          >
            <span>View All Events on Map</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredEvents.map(event => {
            const feasibility = getFeasibility(event);
            return (
              <div
                key={event.id}
                className="bg-white rounded-3xl border border-slate-200 hover:border-brand-300 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="relative h-36 rounded-2xl overflow-hidden bg-slate-100">
                    <img
                      src={event.bannerUrl}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2.5 left-2.5">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/90 text-slate-800">
                        {event.category}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 
                      onClick={() => onSelectEvent(event)}
                      className="font-bold text-slate-900 text-sm hover:text-brand-600 cursor-pointer line-clamp-2"
                    >
                      {event.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 truncate">{event.hostCollege}</p>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Departure:</span>
                    <strong className="font-mono text-brand-700">{feasibility.requiredDepartureTime}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Feasibility:</span>
                    <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onCheckFeasibility(event)}
                  className="w-full py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <Route size={14} />
                  <span>Check Feasibility & Route</span>
                </button>
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
