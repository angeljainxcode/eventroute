import React from 'react';
import { FeasibilityResult } from '../../types/feasibility';
import { formatDuration } from '../../services/feasibilityEngine';
import { 
  LogOut, 
  MapPin, 
  Flag, 
  Clock, 
  ArrowRight, 
  CheckCircle, 
  AlertTriangle, 
  HelpCircle,
  Home
} from 'lucide-react';

interface TimelineBreakdownProps {
  feasibility: FeasibilityResult;
  originName: string;
  venueName: string;
}

export const TimelineBreakdown: React.FC<TimelineBreakdownProps> = ({
  feasibility,
  originName,
  venueName,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-base font-bold text-slate-900">Attendance Journey Timeline</h3>
          <p className="text-xs text-slate-500">Calculated step-by-step schedule to ensure punctual arrival and return</p>
        </div>
        <div className="text-xs font-mono font-semibold px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700">
          Total travel: {formatDuration(feasibility.travelDurationMinutes * 2)} roundtrip
        </div>
      </div>

      {/* Timeline Steps */}
      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
        
        {/* Step 1: Must Leave Origin */}
        <div className="relative group">
          <div className="absolute -left-[27px] top-1 w-6 h-6 rounded-full bg-brand-600 text-white flex items-center justify-center shadow-xs">
            <LogOut size={12} />
          </div>
          <div className="bg-brand-50/60 border border-brand-100 rounded-xl p-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-700">Required Departure</span>
              <span className="text-sm font-extrabold text-brand-800 font-mono bg-white px-2 py-0.5 rounded-md border border-brand-200 shadow-xs">
                {feasibility.requiredDepartureTime}
              </span>
            </div>
            <p className="text-xs font-medium text-slate-700 mt-1">Depart from {originName}</p>
            <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
              <span>Allow {formatDuration(feasibility.travelDurationMinutes)} transit time ({feasibility.distanceKm} km)</span>
            </p>
          </div>
        </div>

        {/* Step 2: Arrive at Venue & Buffer */}
        <div className="relative group">
          <div className="absolute -left-[27px] top-1 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
            <MapPin size={12} />
          </div>
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Expected Arrival at Venue</span>
              <span className="text-sm font-extrabold text-slate-900 font-mono bg-white px-2 py-0.5 rounded-md border border-slate-200">
                {feasibility.expectedArrivalTime}
              </span>
            </div>
            <p className="text-xs font-medium text-slate-700 mt-1">{venueName}</p>
            <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold">
              <CheckCircle size={13} />
              <span>{feasibility.arrivalBufferMinutes} mins safety buffer before kickoff</span>
            </div>
          </div>
        </div>

        {/* Step 3: Event Active Window */}
        <div className="relative group">
          <div className="absolute -left-[27px] top-1 w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Flag size={12} />
          </div>
          <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">Event Session Duration</span>
              <span className="text-sm font-extrabold text-indigo-900 font-mono bg-white px-2 py-0.5 rounded-md border border-indigo-200">
                {feasibility.eventStartTime} – {feasibility.eventEndTime}
              </span>
            </div>
            <p className="text-xs text-indigo-800 mt-1">
              {formatDuration(feasibility.availableTimeAtEventMinutes)} of on-ground participation, hack sprints, or workshops.
            </p>
          </div>
        </div>

        {/* Step 4: Return Journey Departure */}
        <div className="relative group">
          <div className={`absolute -left-[27px] top-1 w-6 h-6 rounded-full text-white flex items-center justify-center shadow-xs ${
            feasibility.returnStatus === 'CONFIRMED'
              ? 'bg-emerald-600'
              : feasibility.returnStatus === 'UNKNOWN'
              ? 'bg-amber-500'
              : 'bg-rose-600'
          }`}>
            {feasibility.returnStatus === 'CONFIRMED' ? (
              <ArrowRight size={12} />
            ) : feasibility.returnStatus === 'UNKNOWN' ? (
              <HelpCircle size={12} />
            ) : (
              <AlertTriangle size={12} />
            )}
          </div>
          <div className={`rounded-xl p-3.5 border ${
            feasibility.returnStatus === 'CONFIRMED'
              ? 'bg-emerald-50/50 border-emerald-200'
              : feasibility.returnStatus === 'UNKNOWN'
              ? 'bg-amber-50/60 border-amber-200'
              : 'bg-rose-50/60 border-rose-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Return Journey Availability
              </span>
              <span className={`text-xs font-extrabold px-2.5 py-0.5 rounded-md ${
                feasibility.returnStatus === 'CONFIRMED'
                  ? 'bg-emerald-600 text-white'
                  : feasibility.returnStatus === 'UNKNOWN'
                  ? 'bg-amber-500 text-white'
                  : 'bg-rose-600 text-white'
              }`}>
                {feasibility.returnStatus === 'CONFIRMED'
                  ? 'CONFIRMED SCHEDULE'
                  : feasibility.returnStatus === 'UNKNOWN'
                  ? 'SCHEDULE UNCONFIRMED'
                  : 'NO VIABLE RETURN'}
              </span>
            </div>

            {feasibility.returnStatus === 'CONFIRMED' && (
              <div className="mt-2 text-xs text-slate-700">
                <p>
                  Latest recommended return: <strong>{feasibility.lastViableReturnDeparture}</strong>
                  {feasibility.matchingReturnTransit && ` (${feasibility.matchingReturnTransit.operator} • ₹${feasibility.matchingReturnTransit.fare})`}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Reaches origin around {feasibility.expectedHomeArrival}
                </p>
              </div>
            )}

            {feasibility.returnStatus === 'UNKNOWN' && (
              <div className="mt-2 text-xs text-amber-900">
                <p className="font-semibold">Return transit availability is unknown from available seed data.</p>
                <p className="text-[11px] text-amber-800 mt-1">
                  Theoretical return departure would be at {feasibility.lastViableReturnDeparture} (reaching around {feasibility.expectedHomeArrival}). Inquire at the local bus stand upon morning arrival.
                </p>
              </div>
            )}

            {feasibility.returnStatus === 'NO_VIABLE_RETURN' && (
              <div className="mt-2 text-xs text-rose-900">
                <p className="font-semibold">No viable return transport found after event closing.</p>
                <p className="text-[11px] text-rose-700 mt-1">
                  Scheduled evening transit departs before the event ends or travel distance prevents single-day return.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Step 5: Back Home */}
        {feasibility.expectedHomeArrival && (
          <div className="relative group">
            <div className="absolute -left-[27px] top-1 w-6 h-6 rounded-full bg-slate-700 text-white flex items-center justify-center shadow-xs">
              <Home size={12} />
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700">Estimated Arrival Back at Origin</span>
              <span className="text-xs font-bold text-slate-900 font-mono">
                ~ {feasibility.expectedHomeArrival}
              </span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
