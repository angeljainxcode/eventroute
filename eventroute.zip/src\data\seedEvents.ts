import { CollegeEvent } from '../types/event';

export const SEED_EVENTS: CollegeEvent[] = [
  {
    id: 'chambal-symposium-2026',
    title: 'Chambal Tech Symposium & Hackathon 2026',
    hostCollege: 'Government Engineering College, Morena',
    venue: 'Main Auditorium, GEC Campus, Morena Highway',
    city: 'Morena',
    coordinates: { lat: 26.5023, lng: 77.9942 }, // ~60 km from ITM Gwalior
    date: '2026-10-24',
    startTime: '10:00',
    endTime: '17:00',
    category: 'Symposium',
    description: 'Annual inter-college engineering symposium featuring competitive problem solving, IoT hardware showcases, and renewable energy technology hackathon. Hands-on mentorship from regional tech leaders.',
    registrationFee: 150,
    eligibility: 'All Engineering & Computer Science Undergraduate/Diploma students',
    registrationUrl: 'https://demo.eventroute.in/register/chambal-tech-2026',
    bannerUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80',
    source: 'Demonstration Benchmark Scenario (Morena GEC Tech Board Demo)',
    lastVerified: '2026-10-14T10:30:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: false, // Initially unknown as specified in prompt!
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 60.5,
      travelDurationMinutes: 212, // 3 hours 32 minutes illustrative
      oneWayCost: 180,             // ₹180 illustrative
      returnScheduleAvailable: false, // initially unknown unless toggled or schedule provided
      notes: 'Central benchmark demo: 60km, 3h 32m travel duration, ₹180 one-way cost, 10:00 AM event start.'
    },
    returnTransitSchedule: [
      {
        type: 'bus',
        operator: 'MP State Rural Bus Service',
        departureTime: '17:35',
        arrivalTime: '21:05',
        fare: 180,
        frequency: 'Every 2 hours',
        originStation: 'Morena Bypass Stop',
        destinationStation: 'Gwalior Stand'
      },
      {
        type: 'train',
        operator: 'Indian Railways (Passenger)',
        departureTime: '18:15',
        arrivalTime: '20:10',
        fare: 65,
        frequency: 'Daily (Unconfirmed evening punctuality)',
        originStation: 'Morena Railway Station (MRA)',
        destinationStation: 'Gwalior Junction (GWL)'
      }
    ]
  },
  {
    id: 'hack-gwalior-2026',
    title: 'HackGwalior 2026 — Smart City & AI Challenge',
    hostCollege: 'Madhav Institute of Technology & Science (MITS)',
    venue: 'Convention Center, MITS Campus, Gola Ka Mandir',
    city: 'Gwalior',
    coordinates: { lat: 26.2307, lng: 78.2148 },
    date: '2026-10-25',
    startTime: '09:30',
    endTime: '18:00',
    category: 'Hackathon',
    description: 'Premier 24-hour hybrid sprint to build civic technology, transport optimizations, and AI assistive solutions for Tier-2 smart cities. Cash prizes worth ₹75,000.',
    registrationFee: 200,
    eligibility: 'College teams of 2 to 4 members. Valid college ID mandatory.',
    registrationUrl: 'https://demo.eventroute.in/register/hackgwalior-2026',
    bannerUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&auto=format&fit=crop&q=80',
    source: 'MITS Coding Club Portal (Demo Sync)',
    lastVerified: '2026-10-15T08:00:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: true,
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 12.4,
      travelDurationMinutes: 35,
      oneWayCost: 40,
      returnScheduleAvailable: true,
      notes: 'Local Gwalior route: easily accessible via city bus, auto, or shared mobility.'
    },
    returnTransitSchedule: [
      {
        type: 'bus',
        operator: 'Gwalior City Transit Line 3',
        departureTime: '18:30',
        arrivalTime: '19:10',
        fare: 30,
        frequency: 'Every 15 mins until 21:30',
        originStation: 'MITS Circle',
        destinationStation: 'Jhansi Road ITM Gate'
      },
      {
        type: 'shared_cab',
        operator: 'Shared Auto / E-Rickshaw Link',
        departureTime: '18:15',
        arrivalTime: '18:55',
        fare: 45,
        frequency: 'Continuous',
        originStation: 'Gola Ka Mandir',
        destinationStation: 'ITM University'
      }
    ]
  },
  {
    id: 'roboclash-jiwaji-2026',
    title: 'RoboClash National Robotics & Drone League',
    hostCollege: 'Jiwaji University, Gwalior',
    venue: 'Indoor Sports Complex, Jiwaji University Campus',
    city: 'Gwalior',
    coordinates: { lat: 26.1953, lng: 78.1772 },
    date: '2026-10-26',
    startTime: '10:00',
    endTime: '16:30',
    category: 'Robotics',
    description: 'High-octane robotic combat (15kg & 30kg), obstacle line follower, and autonomous indoor drone navigation championship with tracks approved by national leagues.',
    registrationFee: 350,
    eligibility: 'UG and Diploma Engineering students across India',
    registrationUrl: 'https://demo.eventroute.in/register/roboclash-jiwaji',
    bannerUrl: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80',
    source: 'Jiwaji Science & Tech Society Notification (Demo)',
    lastVerified: '2026-10-14T18:00:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: true,
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 8.5,
      travelDurationMinutes: 22,
      oneWayCost: 30,
      returnScheduleAvailable: true,
      notes: 'Central city location with rapid transit access.'
    },
    returnTransitSchedule: [
      {
        type: 'bus',
        operator: 'Gwalior Municipal Transit',
        departureTime: '17:00',
        arrivalTime: '17:28',
        fare: 25,
        frequency: 'Every 20 mins',
        originStation: 'Jiwaji Main Gate',
        destinationStation: 'ITM Campus Gate'
      }
    ]
  },
  {
    id: 'designx-iiitm-2026',
    title: 'DesignX — Product UX & Spatial Computing Hack',
    hostCollege: 'ABV-IIITM Gwalior',
    venue: 'Center of Excellence in IT, IIITM Campus',
    city: 'Gwalior',
    coordinates: { lat: 26.2495, lng: 78.1736 },
    date: '2026-10-28',
    startTime: '11:00',
    endTime: '17:30',
    category: 'Workshop',
    description: 'Design systems, accessibility-first design, spatial UI prototyping in Figma, and design sprint presentation to industry design leaders and startup founders.',
    registrationFee: 0, // Free event!
    eligibility: 'Open to all design enthusiasts and developers',
    registrationUrl: 'https://demo.eventroute.in/register/designx-iiitm',
    bannerUrl: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800&auto=format&fit=crop&q=80',
    source: 'IIITM Design Chapter Bulletin (Demo)',
    lastVerified: '2026-10-15T11:00:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: true,
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 18.2,
      travelDurationMinutes: 42,
      oneWayCost: 55,
      returnScheduleAvailable: true,
    },
    returnTransitSchedule: [
      {
        type: 'bus',
        operator: 'Route 10 City Bus',
        departureTime: '18:00',
        arrivalTime: '18:50',
        fare: 35,
        frequency: 'Every 30 mins',
        originStation: 'IIITM Morena Link',
        destinationStation: 'Jhansi Road'
      }
    ]
  },
  {
    id: 'biet-jhansi-drone-iot',
    title: 'Bundelkhand IoT & Autonomous Robotics Expo',
    hostCollege: 'Bundelkhand Institute of Engineering & Technology (BIET)',
    venue: 'Aryabhatta Seminar Hall, BIET Campus',
    city: 'Jhansi',
    coordinates: { lat: 25.4358, lng: 78.5382 }, // ~105 km from Gwalior
    date: '2026-10-30',
    startTime: '09:00',
    endTime: '17:00',
    category: 'Technical Fest',
    description: 'Regional IoT showcase, edge AI hardware benchmarks, and agricultural robotics exhibition. Includes hands-on ESP32 and LoRaWAN workshops with hardware kits.',
    registrationFee: 250,
    eligibility: 'All college students with interest in embedded systems and IoT',
    registrationUrl: 'https://demo.eventroute.in/register/biet-iot-2026',
    bannerUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
    source: 'BIET Technical Council Notice Board (Demo)',
    lastVerified: '2026-10-13T14:00:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: true,
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 104.0,
      travelDurationMinutes: 165, // ~2 hours 45 mins
      oneWayCost: 140,
      returnScheduleAvailable: true,
    },
    returnTransitSchedule: [
      {
        type: 'train',
        operator: 'Shatabdi / Express Return',
        departureTime: '18:25',
        arrivalTime: '20:15',
        fare: 145,
        frequency: 'Daily schedule',
        originStation: 'Jhansi Junction (VGLJ)',
        destinationStation: 'Gwalior Junction (GWL)'
      },
      {
        type: 'bus',
        operator: 'UPSRTC Inter-state Express',
        departureTime: '17:45',
        arrivalTime: '20:45',
        fare: 160,
        frequency: 'Every hour',
        originStation: 'Jhansi Bus Stand',
        destinationStation: 'Gwalior Bus Terminal'
      }
    ]
  },
  {
    id: 'rgpv-bhopal-ai-summit',
    title: 'Central India AI & Web3 Mega Hackathon',
    hostCollege: 'Rajiv Gandhi Proudyogiki Vishwavidyalaya (RGPV)',
    venue: 'University Convention Hall, RGPV Bhopal Campus',
    city: 'Bhopal',
    coordinates: { lat: 23.3104, lng: 77.3621 }, // ~415 km from Gwalior
    date: '2026-11-02',
    startTime: '09:00',
    endTime: '18:00',
    category: 'Hackathon',
    description: 'State-level hackathon organized under Directorate of Technical Education MP. 36-hour track on decentralized applications, sovereign AI models, and FinTech for Bharat.',
    registrationFee: 400,
    eligibility: 'Enrolled students of universities in Central India',
    registrationUrl: 'https://demo.eventroute.in/register/rgpv-ai-hackathon',
    bannerUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
    source: 'RGPV Official University Circular (Demo)',
    lastVerified: '2026-10-12T09:00:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: false, // Distance too large for same-day return without planned overnight stay
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 418.0,
      travelDurationMinutes: 420, // 7 hours
      oneWayCost: 480,
      returnScheduleAvailable: false,
      notes: 'Extreme distance: same-day attendance from Gwalior is not feasible without overnight accommodation.'
    },
    returnTransitSchedule: []
  },
  {
    id: 'cyber-shield-amity-2026',
    title: 'CyberShield CTF & Threat Intelligence Fest',
    hostCollege: 'Amity University Gwalior',
    venue: 'Cyber Forensics Lab, Block B, Amity Campus',
    city: 'Gwalior',
    coordinates: { lat: 26.2736, lng: 78.2315 },
    date: '2026-11-05',
    startTime: '10:00',
    endTime: '16:00',
    category: 'Coding Contest',
    description: 'Jeopardy-style Capture The Flag competition covering cryptography, reverse engineering, web security, and digital forensics. Live red-teaming leaderboard.',
    registrationFee: 100,
    eligibility: 'UG/PG students with basic networking and programming knowledge',
    registrationUrl: 'https://demo.eventroute.in/register/cybershield-amity',
    bannerUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80',
    source: 'Amity Cyber Club Bulletin (Demo)',
    lastVerified: '2026-10-15T09:30:00Z',
    isDemo: true,
    verificationStatus: 'verified_demo',
    hasConfirmedReturnSchedule: true,
    demoScenarioOverride: {
      originCollegeId: 'itm-gwalior',
      distanceKm: 16.0,
      travelDurationMinutes: 38,
      oneWayCost: 50,
      returnScheduleAvailable: true,
    },
    returnTransitSchedule: [
      {
        type: 'bus',
        operator: 'Amity Shuttle & City Link',
        departureTime: '16:30',
        arrivalTime: '17:15',
        fare: 40,
        frequency: 'Scheduled at 16:30, 17:30',
        originStation: 'Amity Main Gate',
        destinationStation: 'Gwalior Railway Station / Jhansi Rd'
      }
    ]
  }
];
