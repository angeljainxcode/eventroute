import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Coordinates } from '../../types/location';
import { fetchRoute, RouteGeometry } from '../../services/routingService';
import { Navigation, Route, MapPin, Compass } from 'lucide-react';

interface RouteMapProps {
  originCoordinates: Coordinates;
  originName: string;
  destinationCoordinates: Coordinates;
  destinationName: string;
  distanceKm: number;
  durationMinutes: number;
}

export const RouteMap: React.FC<RouteMapProps> = ({
  originCoordinates,
  originName,
  destinationCoordinates,
  destinationName,
  distanceKm,
  durationMinutes,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);

  const [routeData, setRouteData] = useState<RouteGeometry | null>(null);
  const [isLoadingRoute, setIsLoadingRoute] = useState<boolean>(true);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [
          (originCoordinates.lat + destinationCoordinates.lat) / 2,
          (originCoordinates.lng + destinationCoordinates.lng) / 2,
        ],
        zoom: 9,
        scrollWheelZoom: false,
      });

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        maxZoom: 19,
      }).addTo(map);

      const routeGroup = L.layerGroup().addTo(map);
      routeLayerRef.current = routeGroup;
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Fetch Route and draw polyline
  useEffect(() => {
    let isCancelled = false;
    setIsLoadingRoute(true);

    fetchRoute(
      originCoordinates,
      destinationCoordinates,
      distanceKm,
      durationMinutes
    ).then(res => {
      if (!isCancelled) {
        setRouteData(res);
        setIsLoadingRoute(false);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [originCoordinates, destinationCoordinates, distanceKm, durationMinutes]);

  // Update map polyline and markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    const group = routeLayerRef.current;
    if (!map || !group || !routeData) return;

    group.clearLayers();

    // 1. Origin Icon
    const originIcon = L.divIcon({
      className: 'route-origin-pin',
      html: `
        <div style="background-color: #026bc9; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.3); border: 2px solid #ffffff; font-weight: 700; font-size: 13px;">
          A
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    // 2. Destination Icon
    const destIcon = L.divIcon({
      className: 'route-dest-pin',
      html: `
        <div style="background-color: #16a34a; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.3); border: 2px solid #ffffff; font-weight: 700; font-size: 13px;">
          B
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    const originMarker = L.marker([originCoordinates.lat, originCoordinates.lng], {
      icon: originIcon,
    }).addTo(group);
    originMarker.bindPopup(`<b>Starting Point:</b><br/>${originName}`);

    const destMarker = L.marker([destinationCoordinates.lat, destinationCoordinates.lng], {
      icon: destIcon,
    }).addTo(group);
    destMarker.bindPopup(`<b>Destination Venue:</b><br/>${destinationName}`);

    // 3. Draw Route Polyline
    const polyline = L.polyline(routeData.coordinates, {
      color: '#026bc9',
      weight: 5,
      opacity: 0.85,
      lineCap: 'round',
      lineJoin: 'round',
      dashArray: routeData.source === 'interpolated_corridor' ? '4, 8' : undefined,
    }).addTo(group);

    // Fit map bounds to encompass the route
    const bounds = polyline.getBounds();
    map.fitBounds(bounds, { padding: [40, 40] });
  }, [routeData, originCoordinates, destinationCoordinates, originName, destinationName]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header bar */}
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-slate-700 font-semibold">
          <Route size={15} className="text-brand-600" />
          <span>Interactive Route Corridor ({distanceKm} km)</span>
        </div>
        <div className="flex items-center gap-2">
          {isLoadingRoute ? (
            <span className="text-[11px] text-slate-400 animate-pulse">Calculating path...</span>
          ) : (
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-50 text-brand-700 border border-blue-200">
              {routeData?.source === 'osrm' ? 'OSRM Road Route' : 'Corridor Estimate'}
            </span>
          )}
        </div>
      </div>

      {/* Map View */}
      <div className="relative w-full h-[320px]">
        <div ref={mapContainerRef} className="w-full h-full z-0" />
      </div>

      {/* Turn steps / Route hints */}
      {routeData && routeData.turnSteps && routeData.turnSteps.length > 0 && (
        <div className="p-4 bg-slate-50/70 border-t border-slate-100">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
            <Compass size={13} className="text-brand-600" />
            <span>Transit Corridor Segments</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {routeData.turnSteps.map((step, idx) => (
              <div key={idx} className="flex items-start gap-2 p-2 bg-white rounded-lg border border-slate-200/80">
                <span className="w-4 h-4 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-slate-700 truncate">{step.instruction}</p>
                  <p className="text-[10px] text-slate-400 font-mono">{step.distance}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
