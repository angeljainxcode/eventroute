import React from 'react';
import { CollegeEvent } from '../../types/event';
import { FeasibilityResult } from '../../types/feasibility';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { formatDuration } from '../../services/feasibilityEngine';
import { 
  MapPin, 
  Calendar, 
  Clock, 
  IndianRupee, 
  Bookmark, 
  BookmarkCheck, 
  ArrowRight,
  ShieldCheck,
  Compass,
  AlertTriangle
} from 'lucide-react';

interface EventCardProps {
  event: CollegeEvent;
  feasibility: FeasibilityResult;
  isSaved: boolean;
  onToggleSave: () => void;
  onSelect: (event: CollegeEvent) => void;
  onCheckFeasibility: (event: CollegeEvent) => void;
}

export const EventCard: React.FC<EventCardProps> = ({
  event,
  feasibility,
  isSaved,
  onToggleSave,
  onSelect,
  onCheckFeasibility,
}) => {
  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 hover:border-brand-300 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden group">
      {/* Banner & Floating Badges */}
      <div 
        className="relative h-44 w-full bg-slate-100 overflow-hidden cursor-pointer"
        onClick={() => onSelect(event)}
      >
        <img
          src={event.bannerUrl}
          alt={event.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-black/20" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-md text-slate-800 shadow-xs">
            {event.category}
          </span>

          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              onToggleSave();
            }}
            className={`w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${
              isSaved
                ? 'bg-amber-400 text-slate-900 shadow-md'
                : 'bg-white/80 hover:bg-white text-slate-700 shadow-xs'
            }`}
            title={isSaved ? 'Remove from saved' : 'Save event'}
          >
            {isSaved ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
          </button>
        </div>

        {/* Bottom Banner Info */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
          <div className="flex items-center gap-1.5 text-xs font-semibold drop-shadow-sm">
            <Calendar size={13} />
            <span>{event.date}</span>
          </div>

          <span className="text-xs font-extrabold px-2 py-0.5 rounded-lg bg-emerald-500/90 text-white shadow-xs">
            {event.registrationFee === 0 ? 'Free' : `₹${event.registrationFee}`}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        {/* Title & Host */}
        <div className="space-y-1.5">
          <div className="flex items-start justify-between gap-2">
            <h3 
              onClick={() => onSelect(event)}
              className="font-bold text-slate-900 text-base leading-snug hover:text-brand-600 transition-colors cursor-pointer line-clamp-2"
            >
              {event.title}
            </h3>
          </div>

          <p className="text-xs font-medium text-slate-500 flex items-center gap-1 truncate">
            <MapPin size={13} className="text-slate-400 shrink-0" />
            <span className="truncate">{event.hostCollege} • {event.city}</span>
          </p>
        </div>

        {/* Feasibility Metric Box (THE CORE VALUE PROPOSITION!) */}
        <div className={`p-3.5 rounded-2xl border transition-all ${
          feasibility.verdict === 'FEASIBLE'
            ? 'bg-emerald-50/60 border-emerald-200'
            : feasibility.verdict === 'DIFFICULT'
            ? 'bg-amber-50/60 border-amber-200'
            : 'bg-rose-50/60 border-rose-200'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
            <span className="text-[11px] font-mono font-semibold text-slate-600">
              {feasibility.distanceKm} km away
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Must Leave</span>
              <strong className="text-slate-900 font-mono text-[13px]">{feasibility.requiredDepartureTime}</strong>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Est. Roundtrip</span>
              <strong className="text-slate-900 font-mono text-[13px]">₹{feasibility.estimatedRoundTripCost}</strong>
            </div>
          </div>

          {/* Quick Warning or Return indicator */}
          <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
            <span className="text-slate-500 truncate max-w-[170px]">
              {feasibility.returnStatus === 'CONFIRMED'
                ? `Return transit: ${feasibility.lastViableReturnDeparture}`
                : feasibility.returnStatus === 'UNKNOWN'
                ? 'Return schedule: Unknown'
                : 'No viable return'}
            </span>
            <span className="text-slate-400 text-[10px]">{formatDuration(feasibility.travelDurationMinutes)} trip</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-1 flex items-center gap-2">
          <button
            type="button"
            onClick={() => onSelect(event)}
            className="flex-1 py-2 px-3 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors"
          >
            Details
          </button>

          <button
            type="button"
            onClick={() => onCheckFeasibility(event)}
            className="flex-2 py-2 px-3.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold transition-all shadow-xs hover:shadow flex items-center justify-center gap-1.5"
          >
            <span>Check Feasibility</span>
            <ArrowRight size={13} />
          </button>
        </div>

      </div>
    </div>
  );
};
