import { Coordinates } from '../types/location';

export interface RouteGeometry {
  coordinates: [number, number][]; // [lat, lng] pairs for Leaflet Polyline
  distanceKm: number;
  durationMinutes: number;
  source: 'osrm' | 'interpolated_corridor';
  turnSteps?: { instruction: string; distance: string }[];
}

const routeCache = new Map<string, RouteGeometry>();

/**
 * Generates an interpolated realistic curve between two coordinates with waypoint jitter
 * to represent realistic road routing when offline or API is unavailable.
 */
function generateFallbackCorridor(
  start: Coordinates,
  end: Coordinates,
  estimatedDistanceKm: number,
  estimatedDurationMins: number
): RouteGeometry {
  const points: [number, number][] = [];
  const steps = 14;

  const latDelta = end.lat - start.lat;
  const lngDelta = end.lng - start.lng;

  points.push([start.lat, start.lng]);

  for (let i = 1; i < steps; i++) {
    const fraction = i / steps;
    // Base straight line
    let lat = start.lat + latDelta * fraction;
    let lng = start.lng + lngDelta * fraction;

    // Add gentle organic road curvature
    const perpendicularAngle = Math.sin(fraction * Math.PI) * 0.008;
    lat += perpendicularAngle * (fraction % 2 === 0 ? 0.7 : -0.7);
    lng += perpendicularAngle * 0.5;

    points.push([Number(lat.toFixed(6)), Number(lng.toFixed(6))]);
  }

  points.push([end.lat, end.lng]);

  const turnSteps = [
    { instruction: 'Depart origin along connecting arterial road', distance: '1.2 km' },
    { instruction: 'Merge onto regional highway corridor towards destination', distance: `${(estimatedDistanceKm * 0.75).toFixed(1)} km` },
    { instruction: 'Take campus/venue access road off highway', distance: '2.5 km' },
    { instruction: 'Arrive at destination campus gate / parking entrance', distance: '0.4 km' },
  ];

  return {
    coordinates: points,
    distanceKm: estimatedDistanceKm,
    durationMinutes: estimatedDurationMins,
    source: 'interpolated_corridor',
    turnSteps,
  };
}

/**
 * Fetches routing from public OSRM router with graceful fallback
 */
export async function fetchRoute(
  start: Coordinates,
  end: Coordinates,
  fallbackDistanceKm: number = 30,
  fallbackDurationMinutes: number = 45
): Promise<RouteGeometry> {
  const cacheKey = `${start.lat.toFixed(4)},${start.lng.toFixed(4)}->${end.lat.toFixed(4)},${end.lng.toFixed(4)}`;
  if (routeCache.has(cacheKey)) {
    return routeCache.get(cacheKey)!;
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000); // 4s timeout

    // OSRM coordinates order is: {longitude},{latitude};{longitude},{latitude}
    const url = `https://router.project-osrm.org/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?overview=full&geometries=geojson&steps=true`;
    
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      if (data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        // GeoJSON coordinates are [lng, lat], Leaflet expects [lat, lng]
        const latLngs: [number, number][] = route.geometry.coordinates.map(
          (pt: [number, number]) => [pt[1], pt[0]]
        );

        const turnSteps: { instruction: string; distance: string }[] = [];
        if (route.legs && route.legs[0] && route.legs[0].steps) {
          route.legs[0].steps.slice(0, 5).forEach((step: any) => {
            if (step.maneuver && step.name) {
              turnSteps.push({
                instruction: `${step.maneuver.type} onto ${step.name || 'road'}`,
                distance: `${(step.distance / 1000).toFixed(1)} km`,
              });
            }
          });
        }

        const result: RouteGeometry = {
          coordinates: latLngs,
          distanceKm: Math.round((route.distance / 1000) * 10) / 10,
          durationMinutes: Math.round(route.duration / 60),
          source: 'osrm',
          turnSteps: turnSteps.length > 0 ? turnSteps : undefined,
        };

        routeCache.set(cacheKey, result);
        return result;
      }
    }
  } catch (err) {
    // Graceful fallback on network error or timeout
  }

  // Fallback
  const fallback = generateFallbackCorridor(
    start,
    end,
    fallbackDistanceKm,
    fallbackDurationMinutes
  );
  routeCache.set(cacheKey, fallback);
  return fallback;
}
