import { CollegeOrigin } from '../types/location';

export const COLLEGES: CollegeOrigin[] = [
  {
    id: 'itm-gwalior',
    name: 'ITM University / ITM GOI, Gwalior',
    shortName: 'ITM Gwalior',
    city: 'Gwalior',
    coordinates: { lat: 26.1362, lng: 78.2045 },
    address: 'NH-75, Jhansi Road, Gwalior, MP 474001',
  },
  {
    id: 'mits-gwalior',
    name: 'Madhav Institute of Technology & Science (MITS)',
    shortName: 'MITS Gwalior',
    city: 'Gwalior',
    coordinates: { lat: 26.2307, lng: 78.2148 },
    address: 'Race Course Road, Gola Ka Mandir, Gwalior, MP 474005',
  },
  {
    id: 'jiwaji-gwalior',
    name: 'Jiwaji University, Gwalior',
    shortName: 'Jiwaji University',
    city: 'Gwalior',
    coordinates: { lat: 26.1953, lng: 78.1772 },
    address: 'Sachin Tendulkar Marg, Gwalior, MP 474011',
  },
  {
    id: 'iiitm-gwalior',
    name: 'ABV - Indian Institute of Information Technology & Management',
    shortName: 'ABV-IIITM Gwalior',
    city: 'Gwalior',
    coordinates: { lat: 26.2495, lng: 78.1736 },
    address: 'Morena Link Road, Gwalior, MP 474015',
  },
  {
    id: 'rgpv-bhopal',
    name: 'Rajiv Gandhi Proudyogiki Vishwavidyalaya (RGPV)',
    shortName: 'RGPV Bhopal',
    city: 'Bhopal',
    coordinates: { lat: 23.3104, lng: 77.3621 },
    address: 'Airport Road, Gandhi Nagar, Bhopal, MP 462033',
  },
  {
    id: 'biet-jhansi',
    name: 'Bundelkhand Institute of Engineering & Technology (BIET)',
    shortName: 'BIET Jhansi',
    city: 'Jhansi',
    coordinates: { lat: 25.4358, lng: 78.5382 },
    address: 'Kanpur Road, Jhansi, UP 284128',
  },
];

export const DEFAULT_COLLEGE = COLLEGES[0]; // ITM Gwalior
