import React, { useState } from 'react';
import { CollegeEvent } from '../../types/event';
import { CollegeOrigin, TravelMode } from '../../types/location';
import { UserPreferences } from '../../types/userPreferences';
import { FeasibilityResult } from '../../types/feasibility';
import { calculateFeasibility, formatDuration } from '../../services/feasibilityEngine';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { RouteMap } from './RouteMap';
import { TimelineBreakdown } from './TimelineBreakdown';
import { TransitScheduleTable } from './TransitScheduleTable';
import { COLLEGES } from '../../data/colleges';
import { 
  ArrowLeft, 
  MapPin, 
  Clock, 
  IndianRupee, 
  Calendar, 
  Bookmark, 
  BookmarkCheck, 
  ExternalLink, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Sliders, 
  Info, 
  ShieldCheck, 
  Share2,
  RefreshCw,
  Bus,
  Train,
  Bike,
  Car
} from 'lucide-react';

interface FeasibilityDashboardProps {
  event: CollegeEvent;
  origin: CollegeOrigin;
  preferences: UserPreferences;
  isSaved: boolean;
  onToggleSave: () => void;
  onBack: () => void;
  onUpdateOrigin?: (origin: CollegeOrigin) => void;
}

export const FeasibilityDashboard: React.FC<FeasibilityDashboardProps> = ({
  event,
  origin,
  preferences,
  isSaved,
  onToggleSave,
  onBack,
  onUpdateOrigin,
}) => {
  // Local interactive parameter tuning for real-time sandbox exploration
  const [activeOriginId, setActiveOriginId] = useState<string>(origin.id);
  const [arrivalBuffer, setArrivalBuffer] = useState<number>(preferences.arrivalBufferMinutes);
  const [returnBuffer, setReturnBuffer] = useState<number>(preferences.returnBufferMinutes);
  const [budget, setBudget] = useState<number>(preferences.budget);
  const [travelMode, setTravelMode] = useState<TravelMode>(preferences.travelMode);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);

  // Active Origin object
  const currentOrigin = COLLEGES.find(c => c.id === activeOriginId) || origin;

  // Calculate live feasibility with local adjustments
  const feasibility: FeasibilityResult = calculateFeasibility(event, currentOrigin, {
    arrivalBufferMinutes: arrivalBuffer,
    postEventDepartureBufferMinutes: returnBuffer,
    maxBudget: budget,
    travelMode: travelMode,
  });

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  // Color schemes based on verdict
  const verdictStyles = {
    FEASIBLE: {
      border: 'border-emerald-200',
      bgLight: 'bg-emerald-50/60',
      text: 'text-emerald-800',
      bannerBg: 'from-emerald-500 to-teal-600',
      icon: CheckCircle2,
    },
    DIFFICULT: {
      border: 'border-amber-200',
      bgLight: 'bg-amber-50/60',
      text: 'text-amber-800',
      bannerBg: 'from-amber-500 to-orange-600',
      icon: AlertTriangle,
    },
    NOT_FEASIBLE: {
      border: 'border-rose-200',
      bgLight: 'bg-rose-50/60',
      text: 'text-rose-800',
      bannerBg: 'from-rose-500 to-red-600',
      icon: XCircle,
    },
  }[feasibility.verdict];

  const VerdictIcon = verdictStyles.icon;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Navigation & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft size={16} />
          <span>Back to Event Discovery</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-xs transition-colors"
          >
            <Share2 size={14} />
            <span>{copiedShare ? 'Link Copied!' : 'Share Itinerary'}</span>
          </button>

          <button
            onClick={onToggleSave}
            className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
              isSaved
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200'
            }`}
          >
            {isSaved ? <BookmarkCheck size={14} className="text-amber-600" /> : <Bookmark size={14} />}
            <span>{isSaved ? 'Saved in Shortlist' : 'Save Event'}</span>
          </button>
        </div>
      </div>

      {/* Main Verdict Hero Banner */}
      <div className={`rounded-3xl p-6 sm:p-8 text-white bg-gradient-to-r ${verdictStyles.bannerBg} shadow-lg relative overflow-hidden`}>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2.5">
              <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-extrabold uppercase tracking-wider">
                Feasibility Verdict
              </span>
              <span className="text-xs text-white/80">
                Calibrated for {currentOrigin.shortName}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <VerdictIcon size={36} className="shrink-0 text-white" />
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                {feasibility.verdictTitle}
              </h1>
            </div>

            <p className="text-sm sm:text-base text-white/95 leading-relaxed">
              {feasibility.verdictSummary}
            </p>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 gap-3 min-w-[280px]">
            <div className="bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/20">
              <div className="text-[11px] uppercase tracking-wider text-white/75 font-semibold">Must Leave By</div>
              <div className="text-lg font-black font-mono mt-0.5">{feasibility.requiredDepartureTime}</div>
              <div className="text-[10px] text-white/80">Arrives at {feasibility.expectedArrivalTime}</div>
            </div>

            <div className="bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/20">
              <div className="text-[11px] uppercase tracking-wider text-white/75 font-semibold">Roundtrip Travel</div>
              <div className="text-lg font-black font-mono mt-0.5">₹{feasibility.estimatedRoundTripCost}</div>
              <div className="text-[10px] text-white/80">{feasibility.distanceKm} km each way</div>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Left Column = Analysis & Timeline | Right Column = Live Sandbox Tuner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left 8 Columns: Explanations, Key Cards, Timeline, Route Map */}
        <div className="lg:col-span-8 space-y-6">

          {/* Core Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mb-1">
                <Clock size={14} className="text-brand-600" />
                <span>Travel Duration</span>
              </div>
              <div className="text-lg font-black text-slate-900 font-mono">
                {formatDuration(feasibility.travelDurationMinutes)}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {feasibility.isScenarioCalibrated ? 'Benchmark timing' : 'Estimated transit'}
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mb-1">
                <IndianRupee size={14} className="text-emerald-600" />
                <span>One-Way Cost</span>
              </div>
              <div className="text-lg font-black text-slate-900 font-mono">
                ₹{feasibility.estimatedOneWayCost}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Total trip: ₹{feasibility.totalTripEstimatedCost}
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mb-1">
                <Calendar size={14} className="text-indigo-600" />
                <span>Event Window</span>
              </div>
              <div className="text-base font-black text-slate-900 font-mono">
                {event.startTime} - {event.endTime}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {formatDuration(feasibility.availableTimeAtEventMinutes)} participation
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mb-1">
                <MapPin size={14} className="text-amber-600" />
                <span>Return Status</span>
              </div>
              <div className={`text-xs font-bold uppercase tracking-wider mt-1 ${
                feasibility.returnStatus === 'CONFIRMED'
                  ? 'text-emerald-700'
                  : feasibility.returnStatus === 'UNKNOWN'
                  ? 'text-amber-700'
                  : 'text-rose-700'
              }`}>
                {feasibility.returnStatus}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {feasibility.lastViableReturnDeparture ? `Last: ${feasibility.lastViableReturnDeparture}` : 'No viable return'}
              </div>
            </div>
          </div>

          {/* Verdict Explanation & Rationales */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700">
              Deterministic Feasibility Evaluation Breakdown
            </h3>

            {/* Reasons List */}
            <div className="space-y-2">
              {feasibility.reasons.map((reason, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                  <div className="w-1.5 h-1.5 rounded-full bg-brand-600 mt-1.5 shrink-0" />
                  <p className="leading-relaxed">{reason}</p>
                </div>
              ))}
            </div>

            {/* Warnings List */}
            {feasibility.warnings.length > 0 && (
              <div className="p-3.5 bg-amber-50/80 rounded-xl border border-amber-200 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                  <AlertTriangle size={14} className="text-amber-600" />
                  <span>Important Travel Cautions</span>
                </div>
                {feasibility.warnings.map((w, idx) => (
                  <p key={idx} className="text-xs text-amber-800 pl-5">
                    • {w}
                  </p>
                ))}
              </div>
            )}

            {/* Suggestions */}
            {feasibility.suggestions.length > 0 && (
              <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-brand-900">
                  <Info size={14} className="text-brand-600" />
                  <span>Feasibility Optimization Advice</span>
                </div>
                {feasibility.suggestions.map((s, idx) => (
                  <p key={idx} className="text-xs text-brand-800 pl-5">
                    • {s}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* Journey Timeline */}
          <TimelineBreakdown
            feasibility={feasibility}
            originName={currentOrigin.name}
            venueName={event.venue}
          />

          {/* Interactive Route Map */}
          <RouteMap
            originCoordinates={currentOrigin.coordinates}
            originName={currentOrigin.name}
            destinationCoordinates={event.coordinates}
            destinationName={event.venue}
            distanceKm={feasibility.distanceKm}
            durationMinutes={feasibility.travelDurationMinutes}
          />

          {/* Return Transit Timetable */}
          <TransitScheduleTable
            options={feasibility.allReturnOptions || []}
            isConfirmed={feasibility.returnStatus === 'CONFIRMED'}
            eventEndTime={event.endTime}
          />

        </div>

        {/* Right 4 Columns: Interactive Sandbox Parameter Tuner & Event Summary */}
        <div className="lg:col-span-4 space-y-6">

          {/* Sandbox Live Recalculation Widget */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5 sticky top-20">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sliders size={16} className="text-brand-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Live Feasibility Sandbox
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setArrivalBuffer(preferences.arrivalBufferMinutes);
                  setReturnBuffer(preferences.returnBufferMinutes);
                  setBudget(preferences.budget);
                  setTravelMode(preferences.travelMode);
                  setActiveOriginId(origin.id);
                }}
                className="text-[11px] text-slate-400 hover:text-brand-600 flex items-center gap-1 transition-colors"
              >
                <RefreshCw size={11} /> Reset
              </button>
            </div>

            {/* Change Origin Dropdown */}
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Starting College
              </label>
              <select
                value={activeOriginId}
                onChange={e => {
                  setActiveOriginId(e.target.value);
                  const selected = COLLEGES.find(c => c.id === e.target.value);
                  if (selected && onUpdateOrigin) onUpdateOrigin(selected);
                }}
                className="w-full text-xs font-medium px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-brand-500"
              >
                {COLLEGES.map(col => (
                  <option key={col.id} value={col.id}>
                    {col.name} ({col.city})
                  </option>
                ))}
              </select>
            </div>

            {/* Travel Mode Selector */}
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Travel Mode
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'transit', label: 'Transit / Bus', icon: Bus },
                  { id: 'train', label: 'Train', icon: Train },
                  { id: 'bike', label: 'Two-Wheeler', icon: Bike },
                  { id: 'cab', label: 'Cab / Shared', icon: Car },
                ].map(m => {
                  const Icon = m.icon;
                  const isSel = travelMode === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setTravelMode(m.id as TravelMode)}
                      className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all ${
                        isSel
                          ? 'border-brand-600 bg-brand-50 text-brand-700 font-bold'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <Icon size={13} />
                      <span>{m.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Arrival Buffer Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Arrival Safety Buffer
                </span>
                <span className="text-xs font-bold text-brand-600 font-mono">
                  {arrivalBuffer} mins
                </span>
              </div>
              <input
                type="range"
                min={10}
                max={90}
                step={5}
                value={arrivalBuffer}
                onChange={e => setArrivalBuffer(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>10m (Tight)</span>
                <span>48m (Scenario)</span>
                <span>90m (Relaxed)</span>
              </div>
            </div>

            {/* Student Budget Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Student Budget
                </span>
                <span className="text-xs font-bold text-emerald-600 font-mono">
                  ₹{budget}
                </span>
              </div>
              <input
                type="range"
                min={100}
                max={2000}
                step={50}
                value={budget}
                onChange={e => setBudget(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>₹100</span>
                <span>₹600</span>
                <span>₹2,000</span>
              </div>
            </div>

            {/* Dynamic Result Summary pill */}
            <div className={`p-3 rounded-xl border text-xs ${verdictStyles.bgLight} ${verdictStyles.border}`}>
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
              </div>
              <p className="text-[11px] text-slate-700">
                Departure required at <strong>{feasibility.requiredDepartureTime}</strong> to reach by <strong>{feasibility.expectedArrivalTime}</strong>.
              </p>
            </div>
          </div>

          {/* Event Quick Details Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Event Information
            </h4>

            <div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">{event.title}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{event.hostCollege}</p>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex items-start gap-2">
                <MapPin size={14} className="text-slate-400 mt-0.5 shrink-0" />
                <span>{event.venue}, {event.city}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={14} className="text-slate-400 shrink-0" />
                <span>{event.date} ({event.startTime} - {event.endTime})</span>
              </div>
              <div className="flex items-center gap-2">
                <IndianRupee size={14} className="text-slate-400 shrink-0" />
                <span>Registration Fee: {event.registrationFee === 0 ? 'Free' : `₹${event.registrationFee}`}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <a
                href={event.registrationUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs text-center flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <span>Register for Event (Demo Link)</span>
                <ExternalLink size={13} />
              </a>

              <div className="flex items-center gap-1.5 text-[10px] text-slate-400 justify-center">
                <ShieldCheck size={12} className="text-brand-600" />
                <span>Source: {event.source}</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
