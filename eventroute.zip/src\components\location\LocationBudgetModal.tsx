import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { COLLEGES } from '../../data/colleges';
import { CollegeOrigin, TravelMode } from '../../types/location';
import { 
  MapPin, 
  IndianRupee, 
  Bus, 
  Train, 
  Bike, 
  Car, 
  Clock, 
  X, 
  Check, 
  Sparkles,
  Building2
} from 'lucide-react';

interface LocationBudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LocationBudgetModal: React.FC<LocationBudgetModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { origin, preferences, setOrigin, updatePreferences, events, getFeasibility } = useApp();

  const [selectedCollegeId, setSelectedCollegeId] = useState<string>(origin.id);
  const [customName, setCustomName] = useState<string>(origin.isCustom ? origin.name : '');
  const [budget, setBudget] = useState<number>(preferences.budget);
  const [travelMode, setTravelMode] = useState<TravelMode>(preferences.travelMode);
  const [arrivalBuffer, setArrivalBuffer] = useState<number>(preferences.arrivalBufferMinutes);
  const [returnBuffer, setReturnBuffer] = useState<number>(preferences.returnBufferMinutes);

  if (!isOpen) return null;

  // Live count of feasible events with these draft settings
  const tempOrigin = selectedCollegeId === 'custom'
    ? {
        id: 'custom-origin',
        name: customName || 'Custom Location (Gwalior)',
        shortName: customName || 'Custom',
        city: 'Gwalior',
        coordinates: { lat: 26.2183, lng: 78.1828 }, // Gwalior central
        address: 'Custom Starting Point, Gwalior, MP',
        isCustom: true,
      }
    : COLLEGES.find(c => c.id === selectedCollegeId) || COLLEGES[0];

  const feasibleCount = events.filter(e => {
    // Quick test
    return true; // We can show total available
  }).length;

  const handleApply = () => {
    if (selectedCollegeId === 'custom') {
      const customOrigin: CollegeOrigin = {
        id: `custom-${Date.now()}`,
        name: customName.trim() || 'Custom Location, Gwalior',
        shortName: customName.trim().slice(0, 15) || 'Custom',
        city: 'Gwalior',
        coordinates: { lat: 26.2183, lng: 78.1828 },
        address: customName.trim() || 'Custom Gwalior Point',
        isCustom: true,
      };
      setOrigin(customOrigin);
    } else {
      const found = COLLEGES.find(c => c.id === selectedCollegeId);
      if (found) setOrigin(found);
    }

    updatePreferences({
      budget,
      travelMode,
      arrivalBufferMinutes: arrivalBuffer,
      returnBufferMinutes: returnBuffer,
    });

    onClose();
  };

  const travelModes: { id: TravelMode; label: string; icon: React.FC<any> }[] = [
    { id: 'transit', label: 'All Transit (Bus/Train)', icon: Bus },
    { id: 'bus', label: 'Bus Only', icon: Bus },
    { id: 'train', label: 'Train Only', icon: Train },
    { id: 'bike', label: 'Two Wheeler / Bike', icon: Bike },
    { id: 'cab', label: 'Cab / Shared Auto', icon: Car },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-100 w-full max-w-xl overflow-hidden flex flex-col max-h-[92vh] animate-scaleUp"
        role="dialog"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/70 via-white to-indigo-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center shadow-xs">
              <MapPin size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Choose Starting Location & Budget</h2>
              <p className="text-xs text-slate-500">EventRoute calibrates arrival timings and costs from here</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Starting College Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Select Starting College or Base Location
            </label>
            <div className="space-y-2">
              {COLLEGES.map(col => {
                const isSelected = selectedCollegeId === col.id;
                return (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => setSelectedCollegeId(col.id)}
                    className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                      isSelected
                        ? 'border-brand-600 bg-brand-50/70 shadow-xs ring-1 ring-brand-500'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 p-1.5 rounded-lg ${isSelected ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                        <Building2 size={16} />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-900">{col.name}</div>
                        <div className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                          <span>{col.city}, MP</span>
                          <span>•</span>
                          <span className="truncate max-w-[260px]">{col.address}</span>
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-brand-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                        <Check size={12} strokeWidth={3} />
                      </div>
                    )}
                  </button>
                );
              })}

              {/* Custom Location Option */}
              <button
                type="button"
                onClick={() => setSelectedCollegeId('custom')}
                className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                  selectedCollegeId === 'custom'
                    ? 'border-brand-600 bg-brand-50/70 shadow-xs ring-1 ring-brand-500'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 bg-white'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1.5 rounded-lg ${selectedCollegeId === 'custom' ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                    <MapPin size={16} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">Custom Address / City Location</div>
                    <div className="text-xs text-slate-500 mt-0.5">Enter a custom hostel, landmark, or nearby town</div>
                  </div>
                </div>
                {selectedCollegeId === 'custom' && (
                  <div className="w-5 h-5 rounded-full bg-brand-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Check size={12} strokeWidth={3} />
                  </div>
                )}
              </button>
            </div>

            {/* Custom Input Field */}
            {selectedCollegeId === 'custom' && (
              <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Location or Hostel Landmark
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={e => setCustomName(e.target.value)}
                  placeholder="e.g. City Center, Gwalior or Phoolbagh"
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-hidden bg-white"
                />
              </div>
            )}
          </div>

          {/* Travel Budget Setting */}
          <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <IndianRupee size={16} className="text-brand-600" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Student Travel Budget</span>
              </div>
              <span className="text-base font-extrabold text-brand-700 px-2.5 py-0.5 bg-brand-100/80 rounded-lg">
                ₹{budget}
              </span>
            </div>
            <input
              type="range"
              min={100}
              max={2500}
              step={50}
              value={budget}
              onChange={e => setBudget(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-mono">
              <span>₹100 (Tight local)</span>
              <span>₹600 (Recommended)</span>
              <span>₹2,500 (Regional)</span>
            </div>
          </div>

          {/* Preferred Travel Mode */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Preferred Travel Mode
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {travelModes.map(mode => {
                const Icon = mode.icon;
                const isSelected = travelMode === mode.id;
                return (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setTravelMode(mode.id)}
                    className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'border-brand-600 bg-brand-50 text-brand-700 font-bold shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <Icon size={14} className={isSelected ? 'text-brand-600' : 'text-slate-400'} />
                    <span className="truncate">{mode.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Timing Buffer Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <Clock size={13} className="text-brand-600" /> Arrival Buffer
                </span>
                <span className="text-xs font-bold text-brand-600">{arrivalBuffer} mins</span>
              </div>
              <p className="text-[11px] text-slate-500 mb-2">Time before event kickoff to register & settle in</p>
              <div className="flex gap-1.5">
                {[15, 30, 48, 60].map(mins => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setArrivalBuffer(mins)}
                    className={`flex-1 py-1 text-xs rounded-lg border font-medium transition-all ${
                      arrivalBuffer === mins
                        ? 'bg-brand-600 text-white border-brand-600'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {mins}m{mins === 48 ? ' ★' : ''}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <Clock size={13} className="text-brand-600" /> Return Transit Buffer
                </span>
                <span className="text-xs font-bold text-brand-600">{returnBuffer} mins</span>
              </div>
              <p className="text-[11px] text-slate-500 mb-2">Time after event wrap-up to reach station/bus</p>
              <div className="flex gap-1.5">
                {[15, 30, 45, 60].map(mins => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setReturnBuffer(mins)}
                    className={`flex-1 py-1 text-xs rounded-lg border font-medium transition-all ${
                      returnBuffer === mins
                        ? 'bg-brand-600 text-white border-brand-600'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            <span className="font-semibold text-slate-700">{tempOrigin.shortName}</span>
            <span> • ₹{budget} budget</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApply}
              className="px-5 py-2 text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 rounded-xl transition-all shadow-xs hover:shadow"
            >
              Apply Starting Point
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
