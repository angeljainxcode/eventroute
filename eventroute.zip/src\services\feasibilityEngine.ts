import { CollegeEvent, TransitOption } from '../types/event';
import { 
  FeasibilityConfig, 
  FeasibilityResult, 
  FeasibilityVerdict, 
  ReturnStatus 
} from '../types/feasibility';
import { CollegeOrigin } from '../types/location';

/**
 * Converts "HH:MM" (24h) to minutes from midnight
 */
export function timeStringToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.trim().split(':');
  const hours = parseInt(parts[0], 10) || 0;
  const minutes = parseInt(parts[1], 10) || 0;
  return hours * 60 + minutes;
}

/**
 * Converts minutes from midnight to formatted string "09:12 AM" or "21:10"
 */
export function minutesToTimeString(totalMinutes: number, format12h: boolean = true): string {
  // Normalize within 24h cycle
  let normalized = Math.round(totalMinutes);
  let daysOffset = 0;

  if (normalized < 0) {
    daysOffset = -1;
    normalized = ((normalized % 1440) + 1440) % 1440;
  } else if (normalized >= 1440) {
    daysOffset = Math.floor(normalized / 1440);
    normalized = normalized % 1440;
  }

  const hours24 = Math.floor(normalized / 60);
  const mins = normalized % 60;
  const paddedMins = mins < 10 ? `0${mins}` : `${mins}`;

  if (!format12h) {
    const paddedHours = hours24 < 10 ? `0${hours24}` : `${hours24}`;
    return `${paddedHours}:${paddedMins}${daysOffset > 0 ? ` (+${daysOffset}d)` : daysOffset < 0 ? ' (prev day)' : ''}`;
  }

  const period = hours24 >= 12 ? 'PM' : 'AM';
  const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;
  const paddedHours12 = hours12 < 10 ? `0${hours12}` : `${hours12}`;

  const suffix = daysOffset > 0 ? ` (+${daysOffset}d)` : daysOffset < 0 ? ' (prev day)' : '';
  return `${paddedHours12}:${paddedMins} ${period}${suffix}`;
}

/**
 * Formats duration in minutes to human readable string (e.g. "3h 32m" or "45 mins")
 */
export function formatDuration(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  if (h === 0) return `${m} mins`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

/**
 * Computes estimated distance, travel duration, and cost based on coordinates
 * or calibrated demo overrides
 */
export function estimateTravelMetrics(
  origin: CollegeOrigin,
  event: CollegeEvent,
  travelMode: FeasibilityConfig['travelMode']
): { distanceKm: number; travelDurationMinutes: number; oneWayCost: number; isCalibrated: boolean } {
  // If event has an explicit calibrated demo scenario for this origin, use it
  if (event.demoScenarioOverride && event.demoScenarioOverride.originCollegeId === origin.id) {
    const override = event.demoScenarioOverride;
    // Adjust slightly if mode is different
    let modeMultiplierDuration = 1.0;
    let modeCost = override.oneWayCost;

    if (travelMode === 'bike') {
      modeMultiplierDuration = 0.75;
      modeCost = Math.round(override.distanceKm * 2.2); // ~₹2.2/km fuel
    } else if (travelMode === 'cab') {
      modeMultiplierDuration = 0.65;
      modeCost = Math.round(override.distanceKm * 12); // ~₹12/km cab
    } else if (travelMode === 'train') {
      modeMultiplierDuration = 0.9;
      modeCost = Math.round(override.oneWayCost * 0.7);
    }

    return {
      distanceKm: override.distanceKm,
      travelDurationMinutes: Math.round(override.travelDurationMinutes * modeMultiplierDuration),
      oneWayCost: modeCost,
      isCalibrated: true,
    };
  }

  // Otherwise calculate geodesic distance using Haversine formula
  const lat1 = origin.coordinates.lat;
  const lon1 = origin.coordinates.lng;
  const lat2 = event.coordinates.lat;
  const lon2 = event.coordinates.lng;

  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const directDistance = R * c;

  // Road distance is typically ~1.25x direct distance
  const roadDistanceKm = Math.round(directDistance * 1.25 * 10) / 10;

  // Speeds in km/h based on mode
  let avgSpeedKmH = 30; // City/transit
  let baseCostPerKm = 2.5; // Shared bus/train

  switch (travelMode) {
    case 'bus':
    case 'transit':
      avgSpeedKmH = roadDistanceKm > 40 ? 40 : 25;
      baseCostPerKm = 2.2;
      break;
    case 'train':
      avgSpeedKmH = 50;
      baseCostPerKm = 1.4;
      break;
    case 'bike':
      avgSpeedKmH = 45;
      baseCostPerKm = 2.5;
      break;
    case 'cab':
      avgSpeedKmH = 50;
      baseCostPerKm = 14;
      break;
    case 'any':
    default:
      avgSpeedKmH = roadDistanceKm > 30 ? 38 : 26;
      baseCostPerKm = 2.0;
      break;
  }

  const travelDurationMinutes = Math.max(15, Math.round((roadDistanceKm / avgSpeedKmH) * 60) + 15); // +15m terminal buffer
  const oneWayCost = Math.max(25, Math.round(roadDistanceKm * baseCostPerKm));

  return {
    distanceKm: roadDistanceKm,
    travelDurationMinutes,
    oneWayCost,
    isCalibrated: false,
  };
}

/**
 * Deterministic, testable feasibility calculation engine
 */
export function calculateFeasibility(
  event: CollegeEvent,
  origin: CollegeOrigin,
  config: FeasibilityConfig
): FeasibilityResult {
  const metrics = estimateTravelMetrics(origin, event, config.travelMode);
  const distanceKm = metrics.distanceKm;
  const travelDurationMinutes = metrics.travelDurationMinutes;
  const estimatedOneWayCost = metrics.oneWayCost;
  const estimatedRoundTripCost = estimatedOneWayCost * 2;
  const totalTripEstimatedCost = estimatedRoundTripCost + (event.registrationFee || 0);

  // Time calculations
  const eventStartMinutes = timeStringToMinutes(event.startTime);
  const eventEndMinutes = timeStringToMinutes(event.endTime);
  const arrivalBufferMinutes = Math.max(0, config.arrivalBufferMinutes);
  const postEventDepartureBufferMinutes = Math.max(15, config.postEventDepartureBufferMinutes);

  // Required Departure Time calculation:
  // departureTime = eventStartTime - travelDuration - arrivalBuffer
  const requiredDepartureMinutes = eventStartMinutes - travelDurationMinutes - arrivalBufferMinutes;
  const expectedArrivalMinutes = requiredDepartureMinutes + travelDurationMinutes;

  const requiredDepartureTime = minutesToTimeString(requiredDepartureMinutes);
  const expectedArrivalTime = minutesToTimeString(expectedArrivalMinutes);
  const formattedEventStart = minutesToTimeString(eventStartMinutes);
  const formattedEventEnd = minutesToTimeString(eventEndMinutes);

  const availableTimeAtEventMinutes = Math.max(0, eventEndMinutes - eventStartMinutes);

  // Flags & Evaluations
  const lateArrival = expectedArrivalMinutes > eventStartMinutes;
  const lateArrivalMinutes = Math.max(0, expectedArrivalMinutes - eventStartMinutes);
  const arrivalMarginMinutes = eventStartMinutes - expectedArrivalMinutes; // equal to arrivalBufferMinutes if on schedule

  // Budget evaluation
  const budgetMarginRupees = config.maxBudget - totalTripEstimatedCost;
  const budgetExceeded = totalTripEstimatedCost > config.maxBudget;

  // Return trip evaluation
  let returnStatus: ReturnStatus = 'UNKNOWN';
  let matchingReturnTransit: TransitOption | null = null;
  let lastViableReturnDeparture: string | null = null;
  let expectedHomeArrival: string | null = null;
  let returnTripDurationMinutes = travelDurationMinutes;
  let returnMarginMinutes: number | undefined = undefined;

  const earliestViableReturnDepartureMinutes = eventEndMinutes + postEventDepartureBufferMinutes;

  const isScheduleConfirmed = event.hasConfirmedReturnSchedule === true;

  if (isScheduleConfirmed && event.returnTransitSchedule && event.returnTransitSchedule.length > 0) {
    // Filter scheduled returns that leave after the event finishes + buffer
    const viableOptions = event.returnTransitSchedule.filter(opt => {
      const departureMins = timeStringToMinutes(opt.departureTime);
      return departureMins >= earliestViableReturnDepartureMinutes;
    });

    if (viableOptions.length > 0) {
      returnStatus = 'CONFIRMED';
      // Pick the first viable option or the best one
      matchingReturnTransit = viableOptions[0];
      const matchDepMins = timeStringToMinutes(matchingReturnTransit.departureTime);
      const matchArrMins = timeStringToMinutes(matchingReturnTransit.arrivalTime);
      
      returnMarginMinutes = matchDepMins - eventEndMinutes;
      lastViableReturnDeparture = minutesToTimeString(matchDepMins);
      expectedHomeArrival = minutesToTimeString(matchArrMins);
      returnTripDurationMinutes = Math.max(15, matchArrMins - matchDepMins);
    } else {
      // Return schedule exists, but all scheduled options depart before the event ends!
      returnStatus = 'NO_VIABLE_RETURN';
      const lastScheduled = event.returnTransitSchedule[event.returnTransitSchedule.length - 1];
      if (lastScheduled) {
        lastViableReturnDeparture = minutesToTimeString(timeStringToMinutes(lastScheduled.departureTime));
      }
    }
  } else {
    // No explicit schedule provided in dataset
    if (distanceKm > 250) {
      returnStatus = 'NO_VIABLE_RETURN'; // Distance is too vast for same-day transit return
    } else {
      returnStatus = 'UNKNOWN'; // Return availability unknown
      // Theoretical return estimate
      const theoreticalDep = eventEndMinutes + postEventDepartureBufferMinutes;
      const theoreticalArr = theoreticalDep + travelDurationMinutes;
      lastViableReturnDeparture = minutesToTimeString(theoreticalDep);
      expectedHomeArrival = minutesToTimeString(theoreticalArr);
    }
  }

  // Schedule strain checks
  const isExtremelyEarlyDeparture = requiredDepartureMinutes < 300; // Leaves before 5:00 AM (e.g. 4:30 AM or previous day)
  const isNegativeDeparture = requiredDepartureMinutes < 0; // Requires traveling overnight/previous day
  const arrivesHomeLate = expectedHomeArrival ? timeStringToMinutes(expectedHomeArrival) > 1380 : false; // Arrives home after 11:00 PM
  const tightSchedule = isExtremelyEarlyDeparture || arrivesHomeLate || (arrivalBufferMinutes < 20);

  // Verdict Determination logic (Deterministic & Explainable)
  let verdict: FeasibilityVerdict = 'FEASIBLE';
  const reasons: string[] = [];
  const warnings: string[] = [];
  const suggestions: string[] = [];

  // Critical Failure Cases -> NOT_FEASIBLE
  if (isNegativeDeparture || lateArrival) {
    verdict = 'NOT_FEASIBLE';
    if (lateArrival) {
      reasons.push(`Late arrival: Expected arrival at ${expectedArrivalTime} is after event start time ${formattedEventStart} by ${lateArrivalMinutes} mins.`);
    } else {
      reasons.push(`Travel duration (${formatDuration(travelDurationMinutes)}) makes same-day departure impossible for this event timing.`);
    }
  } else if (returnStatus === 'NO_VIABLE_RETURN') {
    verdict = 'NOT_FEASIBLE';
    reasons.push(
      distanceKm > 250 
        ? `Distance (${distanceKm} km) prevents same-day return. Overnight accommodation required.`
        : `All confirmed return transit departs before the event concludes at ${formattedEventEnd}. No viable same-day return transit.`
    );
  } else if (budgetExceeded && totalTripEstimatedCost > config.maxBudget * 1.5) {
    verdict = 'NOT_FEASIBLE';
    reasons.push(`Estimated total trip cost (₹${totalTripEstimatedCost}) exceeds student budget (₹${config.maxBudget}) by over 50%.`);
  } 
  // Difficult Cases -> DIFFICULT
  else if (
    budgetExceeded || 
    isExtremelyEarlyDeparture || 
    returnStatus === 'UNKNOWN' || 
    tightSchedule ||
    distanceKm > 100
  ) {
    verdict = 'DIFFICULT';

    if (budgetExceeded) {
      reasons.push(`Cost strain: Total trip cost of ₹${totalTripEstimatedCost} exceeds allocated budget of ₹${config.maxBudget} by ₹${Math.abs(budgetMarginRupees)}.`);
      suggestions.push('Consider traveling with college peers or using subsidized regional buses to split costs.');
    }

    if (isExtremelyEarlyDeparture) {
      reasons.push(`Tight early schedule: Requires departure at ${requiredDepartureTime} to reach with ${arrivalBufferMinutes}m buffer.`);
      warnings.push(`Early morning travel before 06:00 AM may have limited public transit links.`);
    }

    if (returnStatus === 'UNKNOWN') {
      reasons.push('Return transit schedule is unconfirmed. Return availability is unknown from available data.');
      warnings.push('Verify local return bus/train timings at the destination station immediately upon arrival.');
    }

    if (distanceKm > 100 && verdict === 'DIFFICULT' && reasons.length === 0) {
      reasons.push(`Long inter-city distance (${distanceKm} km) with high travel fatigue (${formatDuration(travelDurationMinutes)} each way).`);
    }
  } 
  // All checks satisfied -> FEASIBLE
  else {
    verdict = 'FEASIBLE';
    reasons.push(`On-time arrival guaranteed: Departure at ${requiredDepartureTime} provides ${arrivalBufferMinutes}m buffer before event kickoff.`);
    reasons.push(`Trip cost (₹${totalTripEstimatedCost}) is comfortably within student budget of ₹${config.maxBudget}.`);
    if (returnStatus === 'CONFIRMED') {
      reasons.push(`Confirmed return transit available at ${lastViableReturnDeparture}, reaching origin around ${expectedHomeArrival}.`);
    }
  }

  // Verdict Title and User Summary
  let verdictTitle = 'Feasible to Attend';
  let verdictSummary = 'Comfortable travel timing, confirmed schedule, and well within budget.';

  if (verdict === 'DIFFICULT') {
    verdictTitle = 'Difficult / Tight Feasibility';
    verdictSummary = 'Attendance is possible, but demands early departure, strict time buffers, or exceeds preferred budget.';
  } else if (verdict === 'NOT_FEASIBLE') {
    verdictTitle = 'Not Feasible for Single-Day Attendance';
    verdictSummary = 'Timing conflict, late arrival, budget overshoot, or absence of viable return transit.';
  }

  return {
    verdict,
    verdictTitle,
    verdictSummary,
    distanceKm,
    travelDurationMinutes,
    estimatedOneWayCost,
    estimatedRoundTripCost,
    totalTripEstimatedCost,
    budgetExceeded,
    requiredDepartureTime,
    expectedArrivalTime,
    eventStartTime: formattedEventStart,
    eventEndTime: formattedEventEnd,
    availableTimeAtEventMinutes,
    arrivalBufferMinutes,
    lateArrival,
    lateArrivalMinutes,
    returnStatus,
    lastViableReturnDeparture,
    expectedHomeArrival,
    returnTripDurationMinutes,
    matchingReturnTransit,
    allReturnOptions: event.returnTransitSchedule || [],
    breakdown: {
      timelineOk: !lateArrival && !isNegativeDeparture,
      budgetOk: !budgetExceeded,
      returnOk: returnStatus !== 'NO_VIABLE_RETURN',
      arrivalMarginMinutes,
      budgetMarginRupees,
      returnMarginMinutes,
    },
    reasons,
    warnings,
    suggestions,
    isEstimatedTransit: !metrics.isCalibrated,
    isScenarioCalibrated: metrics.isCalibrated,
  };
}
