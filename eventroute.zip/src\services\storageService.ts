import { CollegeEvent } from '../types/event';
import { SEED_EVENTS } from '../data/seedEvents';
import { supabase, isSupabaseConfigured } from './supabaseClient';

const CUSTOM_EVENTS_KEY = 'eventroute_custom_events_v1';
const SAVED_EVENTS_KEY = 'eventroute_saved_event_ids_v1';

/**
 * Loads custom organizer-published events from local storage
 */
export function getLocalCustomEvents(): CollegeEvent[] {
  try {
    const raw = localStorage.getItem(CUSTOM_EVENTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as CollegeEvent[];
  } catch (err) {
    console.error('Failed to parse local custom events', err);
    return [];
  }
}

/**
 * Saves a custom event to local storage
 */
export function saveLocalCustomEvent(event: CollegeEvent): void {
  try {
    const existing = getLocalCustomEvents();
    const updated = [event, ...existing.filter(e => e.id !== event.id)];
    localStorage.setItem(CUSTOM_EVENTS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save event locally', err);
  }
}

/**
 * Fetches all events: combines seed events, local organizer events, and Supabase events if connected
 */
export async function getAllEvents(): Promise<{ events: CollegeEvent[]; source: 'supabase' | 'local_demo' }> {
  const localEvents = getLocalCustomEvents();
  const baseList = [...localEvents, ...SEED_EVENTS];

  if (isSupabaseConfigured && supabase) {
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data && data.length > 0) {
        // Map Supabase rows to CollegeEvent
        const remoteEvents: CollegeEvent[] = data.map((row: any) => ({
          id: row.id,
          title: row.title,
          hostCollege: row.host_college || row.hostCollege,
          venue: row.venue,
          city: row.city || 'Gwalior',
          coordinates: row.coordinates || { lat: row.lat || 26.2, lng: row.lng || 78.2 },
          date: row.date,
          startTime: row.start_time || row.startTime || '10:00',
          endTime: row.end_time || row.endTime || '17:00',
          category: row.category || 'Technical Fest',
          description: row.description || '',
          registrationFee: Number(row.registration_fee ?? row.registrationFee ?? 0),
          eligibility: row.eligibility || 'College Students',
          registrationUrl: row.registration_url || row.registrationUrl || '#',
          bannerUrl: row.banner_url || row.bannerUrl || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
          source: row.source || 'Supabase Remote Event',
          lastVerified: row.last_verified || new Date().toISOString(),
          isDemo: false,
          verificationStatus: 'community_submitted',
          hasConfirmedReturnSchedule: Boolean(row.has_confirmed_return_schedule),
          returnTransitSchedule: row.return_transit_schedule || [],
        }));

        // Merge without duplicates
        const combined = [...remoteEvents, ...baseList];
        const unique = Array.from(new Map(combined.map(e => [e.id, e])).values());
        return { events: unique, source: 'supabase' };
      }
    } catch (err) {
      console.warn('Supabase fetch failed, falling back to local dataset', err);
    }
  }

  return { events: baseList, source: 'local_demo' };
}

/**
 * Creates and publishes a new college event
 */
export async function publishEvent(
  eventInput: Omit<CollegeEvent, 'id' | 'isDemo' | 'verificationStatus' | 'lastVerified'>
): Promise<{ event: CollegeEvent; savedTo: 'supabase' | 'local_demo'; error?: string }> {
  const newId = `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  const newEvent: CollegeEvent = {
    ...eventInput,
    id: newId,
    isDemo: false,
    verificationStatus: 'community_submitted',
    lastVerified: now,
  };

  // Attempt Supabase insert if configured
  if (isSupabaseConfigured && supabase) {
    try {
      const { error } = await supabase.from('events').insert([
        {
          id: newId,
          title: newEvent.title,
          host_college: newEvent.hostCollege,
          venue: newEvent.venue,
          city: newEvent.city,
          coordinates: newEvent.coordinates,
          date: newEvent.date,
          start_time: newEvent.startTime,
          end_time: newEvent.endTime,
          category: newEvent.category,
          description: newEvent.description,
          registration_fee: newEvent.registrationFee,
          eligibility: newEvent.eligibility,
          registration_url: newEvent.registrationUrl,
          banner_url: newEvent.bannerUrl,
          source: newEvent.source,
          last_verified: now,
          has_confirmed_return_schedule: newEvent.hasConfirmedReturnSchedule ?? false,
          return_transit_schedule: newEvent.returnTransitSchedule || [],
        },
      ]);

      if (!error) {
        saveLocalCustomEvent(newEvent);
        return { event: newEvent, savedTo: 'supabase' };
      }
    } catch (err) {
      console.warn('Could not insert to Supabase, falling back to local demo storage', err);
    }
  }

  // Fallback to local storage
  saveLocalCustomEvent(newEvent);
  return { event: newEvent, savedTo: 'local_demo' };
}

/**
 * Saved Events in student shortlist
 */
export function getSavedEventIds(): string[] {
  try {
    const raw = localStorage.getItem(SAVED_EVENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

export function toggleSavedEvent(eventId: string): { isSaved: boolean; allSavedIds: string[] } {
  try {
    const current = getSavedEventIds();
    let updated: string[];
    let isSaved: boolean;

    if (current.includes(eventId)) {
      updated = current.filter(id => id !== eventId);
      isSaved = false;
    } else {
      updated = [...current, eventId];
      isSaved = true;
    }

    localStorage.setItem(SAVED_EVENTS_KEY, JSON.stringify(updated));
    return { isSaved, allSavedIds: updated };
  } catch (err) {
    return { isSaved: false, allSavedIds: [] };
  }
}
