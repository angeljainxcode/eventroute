import { describe, it, expect } from 'vitest';
import { 
  calculateFeasibility, 
  timeStringToMinutes, 
  minutesToTimeString, 
  formatDuration 
} from '../services/feasibilityEngine';
import { COLLEGES } from '../data/colleges';
import { SEED_EVENTS } from '../data/seedEvents';
import { CollegeEvent } from '../types/event';
import { FeasibilityConfig } from '../types/feasibility';

describe('Feasibility Engine — Core Business Logic', () => {
  const itmCollege = COLLEGES.find(c => c.id === 'itm-gwalior')!;
  const chambalEvent = SEED_EVENTS.find(e => e.id === 'chambal-symposium-2026')!;
  const hackGwaliorEvent = SEED_EVENTS.find(e => e.id === 'hack-gwalior-2026')!;

  describe('Time and String Helpers', () => {
    it('converts HH:MM string to minutes correctly', () => {
      expect(timeStringToMinutes('00:00')).toBe(0);
      expect(timeStringToMinutes('05:40')).toBe(340);
      expect(timeStringToMinutes('09:12')).toBe(552);
      expect(timeStringToMinutes('10:00')).toBe(600);
      expect(timeStringToMinutes('17:00')).toBe(1020);
    });

    it('formats minutes to 12h time string correctly', () => {
      expect(minutesToTimeString(340)).toBe('05:40 AM');
      expect(minutesToTimeString(552)).toBe('09:12 AM');
      expect(minutesToTimeString(600)).toBe('10:00 AM');
      expect(minutesToTimeString(1020)).toBe('05:00 PM');
    });

    it('formats duration into readable human text', () => {
      expect(formatDuration(212)).toBe('3h 32m');
      expect(formatDuration(45)).toBe('45 mins');
      expect(formatDuration(120)).toBe('2h');
    });
  });

  describe('Central Demonstration Benchmark Scenario', () => {
    it('accurately calculates departure 05:40 AM and arrival 09:12 AM for 60km Morena event with 48m buffer', () => {
      const config: FeasibilityConfig = {
        arrivalBufferMinutes: 48,
        postEventDepartureBufferMinutes: 30,
        maxBudget: 600,
        travelMode: 'transit',
      };

      const result = calculateFeasibility(chambalEvent, itmCollege, config);

      // Verify exact benchmark numbers specified in product specification:
      // Leave time: 5:40 AM
      // Arrival: 9:12 AM
      // Distance: ~60km
      // Travel duration: 3 hours 32 minutes (212 minutes)
      // One-way cost: ₹180
      expect(result.requiredDepartureTime).toBe('05:40 AM');
      expect(result.expectedArrivalTime).toBe('09:12 AM');
      expect(result.distanceKm).toBeCloseTo(60.5, 0);
      expect(result.travelDurationMinutes).toBe(212);
      expect(result.estimatedOneWayCost).toBe(180);
      expect(result.estimatedRoundTripCost).toBe(360);
      expect(result.totalTripEstimatedCost).toBe(360 + 150); // ₹360 travel + ₹150 registration fee
      
      // Return availability initially unknown as per dataset specification
      expect(result.returnStatus).toBe('UNKNOWN');
      // Because return is unconfirmed and departure is early (05:40 AM), verdict is DIFFICULT
      expect(result.verdict).toBe('DIFFICULT');
      expect(result.warnings.some(w => w.includes('Return transit schedule is unconfirmed') || w.includes('return') || w.includes('early') || w.includes('transit'))).toBe(true);
    });
  });

  describe('Feasible Local Events', () => {
    it('produces FEASIBLE verdict for local Gwalior event with confirmed return and adequate budget', () => {
      const config: FeasibilityConfig = {
        arrivalBufferMinutes: 30,
        postEventDepartureBufferMinutes: 20,
        maxBudget: 500,
        travelMode: 'transit',
      };

      const result = calculateFeasibility(hackGwaliorEvent, itmCollege, config);

      expect(result.verdict).toBe('FEASIBLE');
      expect(result.lateArrival).toBe(false);
      expect(result.budgetExceeded).toBe(false);
      expect(result.returnStatus).toBe('CONFIRMED');
      expect(result.matchingReturnTransit).toBeDefined();
    });
  });

  describe('Budget Constraints Handling', () => {
    it('flags budgetExceeded and marks DIFFICULT or NOT_FEASIBLE when student budget is too low', () => {
      const lowBudgetConfig: FeasibilityConfig = {
        arrivalBufferMinutes: 30,
        postEventDepartureBufferMinutes: 30,
        maxBudget: 100, // Very low budget (trip costs > ₹350)
        travelMode: 'transit',
      };

      const result = calculateFeasibility(chambalEvent, itmCollege, lowBudgetConfig);

      expect(result.budgetExceeded).toBe(true);
      expect(result.breakdown.budgetOk).toBe(false);
      expect(result.verdict).not.toBe('FEASIBLE');
      expect(result.reasons.some(r => r.toLowerCase().includes('budget') || r.toLowerCase().includes('cost'))).toBe(true);
    });
  });

  describe('Late Arrival Handling', () => {
    it('marks NOT_FEASIBLE if travel duration causes arrival after required event start', () => {
      // Create a mock event where travel takes 4 hours, but event starts in 1 hour
      const mockEvent: CollegeEvent = {
        ...hackGwaliorEvent,
        id: 'mock-early-event',
        startTime: '06:00',
        endTime: '12:00',
        demoScenarioOverride: {
          originCollegeId: 'itm-gwalior',
          distanceKm: 250,
          travelDurationMinutes: 400, // 6h 40m travel duration
          oneWayCost: 300,
          returnScheduleAvailable: false,
        }
      };

      const config: FeasibilityConfig = {
        arrivalBufferMinutes: 30,
        postEventDepartureBufferMinutes: 30,
        maxBudget: 1000,
        travelMode: 'transit',
      };

      const result = calculateFeasibility(mockEvent, itmCollege, config);

      expect(result.verdict).toBe('NOT_FEASIBLE');
      expect(result.breakdown.timelineOk).toBe(false);
    });
  });

  describe('Unavailable Return Schedules Handling', () => {
    it('marks NOT_FEASIBLE when all scheduled return transit depart BEFORE the event ends', () => {
      const eventWithEarlyReturnBus: CollegeEvent = {
        ...hackGwaliorEvent,
        id: 'event-early-buses-only',
        startTime: '10:00',
        endTime: '18:00', // Event ends at 6 PM
        returnTransitSchedule: [
          {
            type: 'bus',
            operator: 'Last Morning Bus',
            departureTime: '11:00', // Leaves morning
            arrivalTime: '12:00',
            fare: 40,
            frequency: 'Once',
            originStation: 'Campus Gate',
            destinationStation: 'ITM Gwalior'
          },
          {
            type: 'bus',
            operator: 'Afternoon Bus',
            departureTime: '15:30', // Leaves at 3:30 PM, before 6 PM end!
            arrivalTime: '16:30',
            fare: 40,
            frequency: 'Once',
            originStation: 'Campus Gate',
            destinationStation: 'ITM Gwalior'
          }
        ]
      };

      const config: FeasibilityConfig = {
        arrivalBufferMinutes: 30,
        postEventDepartureBufferMinutes: 20,
        maxBudget: 1000,
        travelMode: 'transit',
      };

      const result = calculateFeasibility(eventWithEarlyReturnBus, itmCollege, config);

      expect(result.returnStatus).toBe('NO_VIABLE_RETURN');
      expect(result.verdict).toBe('NOT_FEASIBLE');
      expect(result.reasons.some(r => r.includes('return') || r.includes('transit'))).toBe(true);
    });

    it('reports UNKNOWN return availability when no return transit data exists, without falsely claiming impossible', () => {
      const eventWithNoReturnData: CollegeEvent = {
        ...hackGwaliorEvent,
        id: 'event-no-return-data',
        returnTransitSchedule: [],
        hasConfirmedReturnSchedule: false,
      };

      const config: FeasibilityConfig = {
        arrivalBufferMinutes: 30,
        postEventDepartureBufferMinutes: 20,
        maxBudget: 1000,
        travelMode: 'transit',
      };

      const result = calculateFeasibility(eventWithNoReturnData, itmCollege, config);

      expect(result.returnStatus).toBe('UNKNOWN');
      // Should clearly inform user that return availability is unknown rather than guaranteeing or denying
      expect(result.reasons.some(r => r.toLowerCase().includes('unknown') || r.toLowerCase().includes('unconfirmed'))).toBe(true);
    });
  });
});
