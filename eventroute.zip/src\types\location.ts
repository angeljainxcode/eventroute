export interface Coordinates {
  lat: number;
  lng: number;
}

export interface CollegeOrigin {
  id: string;
  name: string;
  shortName: string;
  city: string;
  coordinates: Coordinates;
  address: string;
  isCustom?: boolean;
}

export type TravelMode = 'transit' | 'bus' | 'train' | 'bike' | 'cab' | 'any';
