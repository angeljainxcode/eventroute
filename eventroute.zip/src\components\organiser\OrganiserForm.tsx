import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EventCategory } from '../../types/event';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  Clock, 
  IndianRupee, 
  FileText, 
  Link, 
  Image, 
  Sparkles, 
  CheckCircle, 
  AlertCircle,
  Database,
  ArrowLeft
} from 'lucide-react';

interface OrganiserFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const OrganiserForm: React.FC<OrganiserFormProps> = ({
  onSuccess,
  onCancel,
}) => {
  const { addNewEvent, dataSource } = useApp();

  const [title, setTitle] = useState('');
  const [hostCollege, setHostCollege] = useState('');
  const [venue, setVenue] = useState('');
  const [city, setCity] = useState('Gwalior');
  const [lat, setLat] = useState('26.2200');
  const [lng, setLng] = useState('78.1800');
  const [date, setDate] = useState('2026-11-10');
  const [startTime, setStartTime] = useState('10:00');
  const [endTime, setEndTime] = useState('17:00');
  const [category, setCategory] = useState<EventCategory>('Hackathon');
  const [description, setDescription] = useState('');
  const [registrationFee, setRegistrationFee] = useState<number>(0);
  const [eligibility, setEligibility] = useState('Open to all college students');
  const [registrationUrl, setRegistrationUrl] = useState('https://demo.eventroute.in/event-register');
  const [bannerUrl, setBannerUrl] = useState('https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800');
  const [source, setSource] = useState('Organiser Direct Submission');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successNotice, setSuccessNotice] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!title.trim()) {
      setErrorMessage('Please enter an event title');
      return;
    }
    if (!hostCollege.trim()) {
      setErrorMessage('Please enter the hosting college');
      return;
    }
    if (!venue.trim()) {
      setErrorMessage('Please specify the campus venue');
      return;
    }

    setIsSubmitting(true);

    try {
      await addNewEvent({
        title: title.trim(),
        hostCollege: hostCollege.trim(),
        venue: venue.trim(),
        city: city.trim() || 'Gwalior',
        coordinates: {
          lat: parseFloat(lat) || 26.22,
          lng: parseFloat(lng) || 78.18,
        },
        date,
        startTime,
        endTime,
        category,
        description: description.trim() || 'Official inter-college technical event.',
        registrationFee: Number(registrationFee) || 0,
        eligibility: eligibility.trim() || 'College Students',
        registrationUrl: registrationUrl.trim() || 'https://demo.eventroute.in',
        bannerUrl: bannerUrl.trim() || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
        source: source.trim() || 'Community Organizer Submission',
        hasConfirmedReturnSchedule: false,
        returnTransitSchedule: [],
      });

      setSuccessNotice('Event published successfully! Redirecting to discovery...');
      setTimeout(() => {
        onSuccess();
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to publish event. Please check inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* Back button */}
      <button
        onClick={onCancel}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 mb-6 transition-colors"
      >
        <ArrowLeft size={14} />
        <span>Back to Events</span>
      </button>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Header */}
        <div className="px-6 sm:px-8 py-6 border-b border-slate-100 bg-gradient-to-r from-blue-50/80 via-white to-indigo-50/50">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-brand-600 block mb-1">
                Event Submission Portal
              </span>
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Publish an Inter-College Event
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Help students calculate realistic travel feasibility to your fest or hackathon
              </p>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 shadow-xs text-xs font-medium text-slate-600">
              <Database size={13} className="text-brand-600" />
              <span>Storage: {dataSource === 'supabase' ? 'Supabase Postgres' : 'Local Persistence'}</span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle size={15} />
              <span>{errorMessage}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 font-semibold">
              <CheckCircle size={15} />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Title & Host College */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Event Name / Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. InnovateMP 2026 Hackathon"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Host College / University *
                </label>
                <input
                  type="text"
                  required
                  value={hostCollege}
                  onChange={e => setHostCollege(e.target.value)}
                  placeholder="e.g. MITS Gwalior or ITM University"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Category *
                </label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as EventCategory)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:ring-2 focus:ring-brand-500 focus:outline-hidden font-medium"
                >
                  <option value="Hackathon">Hackathon</option>
                  <option value="Technical Fest">Technical Fest</option>
                  <option value="Symposium">Symposium</option>
                  <option value="Workshop">Workshop</option>
                  <option value="Coding Contest">Coding Contest</option>
                  <option value="Robotics">Robotics</option>
                </select>
              </div>
            </div>
          </div>

          {/* Venue & Coordinates */}
          <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-200 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <MapPin size={14} className="text-brand-600" />
              Venue & Geographic Location
            </h3>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Venue Address & Campus Auditorium *
              </label>
              <input
                type="text"
                required
                value={venue}
                onChange={e => setVenue(e.target.value)}
                placeholder="e.g. Main Auditorium, Campus Block A"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs focus:ring-2 focus:ring-brand-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Latitude</label>
                <input
                  type="text"
                  value={lat}
                  onChange={e => setLat(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Longitude</label>
                <input
                  type="text"
                  value={lng}
                  onChange={e => setLng(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Timings & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Event Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Start Time (24h) *
              </label>
              <input
                type="time"
                required
                value={startTime}
                onChange={e => setStartTime(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                End Time (24h) *
              </label>
              <input
                type="time"
                required
                value={endTime}
                onChange={e => setEndTime(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          {/* Registration Fee & Eligibility */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Registration Fee (₹)
              </label>
              <input
                type="number"
                min={0}
                value={registrationFee}
                onChange={e => setRegistrationFee(Number(e.target.value))}
                placeholder="0 for free"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Enter 0 if event is free to attend</span>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Student Eligibility
              </label>
              <input
                type="text"
                value={eligibility}
                onChange={e => setEligibility(e.target.value)}
                placeholder="e.g. All B.Tech/BCA students"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              Event Description & Agenda
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Outline event tracks, prizes, problem statements, and requirements..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
            />
          </div>

          {/* Links & Source */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Registration / Notice URL
              </label>
              <input
                type="url"
                value={registrationUrl}
                onChange={e => setRegistrationUrl(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Verification Source Info
              </label>
              <input
                type="text"
                value={source}
                onChange={e => setSource(e.target.value)}
                placeholder="e.g. College Society Circular"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all disabled:opacity-50 flex items-center gap-2"
            >
              <Sparkles size={14} />
              <span>{isSubmitting ? 'Publishing...' : 'Publish Event'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
