import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CollegeEvent } from '../../types/event';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { EmptyState } from '../common/EmptyState';
import { formatDuration } from '../../services/feasibilityEngine';
import { 
  Bookmark, 
  Trash2, 
  Route, 
  Calendar, 
  Clock, 
  MapPin, 
  IndianRupee, 
  ArrowRight,
  ExternalLink,
  CalendarDays,
  List
} from 'lucide-react';

interface SavedEventsProps {
  onSelectEvent: (event: CollegeEvent) => void;
  onCheckFeasibility: (event: CollegeEvent) => void;
  onExploreEvents: () => void;
}

export const SavedEvents: React.FC<SavedEventsProps> = ({
  onSelectEvent,
  onCheckFeasibility,
  onExploreEvents,
}) => {
  const { events, savedEventIds, toggleSave, getFeasibility, origin } = useApp();
  const [viewMode, setViewMode] = useState<'chronological' | 'calendar'>('chronological');

  const savedList = events.filter(e => savedEventIds.includes(e.id));

  // Sort chronologically by date
  const sortedSaved = [...savedList].sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-brand-600 mb-1">
            <Bookmark size={14} />
            <span>Student Itinerary Shortlist</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            My Saved College Events
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Live departure alarms and feasibility calibrated from <strong>{origin.shortName}</strong>
          </p>
        </div>

        {savedList.length > 0 && (
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl border border-slate-200 self-start sm:self-auto">
            <button
              onClick={() => setViewMode('chronological')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewMode === 'chronological' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List size={14} />
              <span>Timeline View</span>
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewMode === 'calendar' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CalendarDays size={14} />
              <span>Calendar Grid</span>
            </button>
          </div>
        )}
      </div>

      {/* Content */}
      {savedList.length === 0 ? (
        <EmptyState
          title="No events saved yet"
          description="Browse hackathons, robotics challenges, and tech symposiums in discovery mode, then click the bookmark icon to plan your feasibility."
          actionText="Discover Events"
          onAction={onExploreEvents}
        />
      ) : viewMode === 'chronological' ? (
        <div className="space-y-4">
          {sortedSaved.map(event => {
            const feasibility = getFeasibility(event);
            return (
              <div
                key={event.id}
                className="bg-white rounded-3xl border border-slate-200 hover:border-brand-300 p-5 shadow-xs transition-all flex flex-col md:flex-row md:items-center justify-between gap-5"
              >
                {/* Left Info */}
                <div className="flex items-start gap-4">
                  <img
                    src={event.bannerUrl}
                    alt={event.title}
                    className="w-20 h-20 rounded-2xl object-cover shrink-0 border border-slate-100"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
                      <span className="text-[11px] font-semibold text-slate-400">
                        {event.category}
                      </span>
                      <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                        {event.date}
                      </span>
                    </div>

                    <h3 
                      onClick={() => onSelectEvent(event)}
                      className="font-bold text-base text-slate-900 hover:text-brand-600 transition-colors cursor-pointer leading-tight"
                    >
                      {event.title}
                    </h3>

                    <p className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin size={12} className="text-slate-400 shrink-0" />
                      <span>{event.hostCollege} • {feasibility.distanceKm} km away</span>
                    </p>
                  </div>
                </div>

                {/* Center Timing & Travel Pill */}
                <div className="bg-slate-50/80 rounded-2xl p-3 border border-slate-200/80 grid grid-cols-2 gap-3 text-xs min-w-[220px]">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Required Leave</span>
                    <strong className="text-brand-700 font-mono text-sm">{feasibility.requiredDepartureTime}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Roundtrip Cost</span>
                    <strong className="text-slate-800 font-mono text-sm">₹{feasibility.estimatedRoundTripCost}</strong>
                  </div>
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                  <button
                    onClick={() => toggleSave(event.id)}
                    className="p-2.5 rounded-xl border border-slate-200 hover:bg-rose-50 hover:border-rose-200 text-slate-400 hover:text-rose-600 transition-colors"
                    title="Remove from saved"
                  >
                    <Trash2 size={15} />
                  </button>

                  <button
                    onClick={() => onCheckFeasibility(event)}
                    className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                  >
                    <Route size={14} />
                    <span>Route Feasibility</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Calendar-style Card Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {sortedSaved.map(event => {
            const feasibility = getFeasibility(event);
            return (
              <div
                key={event.id}
                className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4 relative"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-extrabold text-brand-700 bg-brand-50 px-2.5 py-1 rounded-xl border border-brand-100 flex items-center gap-1.5">
                      <Calendar size={13} />
                      {event.date}
                    </span>
                    <button
                      onClick={() => toggleSave(event.id)}
                      className="text-slate-400 hover:text-rose-600 transition-colors"
                      title="Remove"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>

                  <h3 
                    onClick={() => onSelectEvent(event)}
                    className="font-bold text-sm text-slate-900 hover:text-brand-600 cursor-pointer line-clamp-2"
                  >
                    {event.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 truncate">{event.hostCollege}</p>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Must Leave:</span>
                    <strong className="font-mono text-slate-900">{feasibility.requiredDepartureTime}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Feasibility:</span>
                    <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
                  </div>
                </div>

                <button
                  onClick={() => onCheckFeasibility(event)}
                  className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Route size={13} />
                  <span>View Route</span>
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
