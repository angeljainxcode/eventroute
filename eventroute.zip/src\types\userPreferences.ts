import { TravelMode } from './location';

export interface UserPreferences {
  originCollegeId: string;
  customOriginName?: string;
  customCoordinates?: { lat: number; lng: number };
  budget: number; // in INR (e.g. 500, 1000)
  travelMode: TravelMode;
  arrivalBufferMinutes: number; // default: 30 or 48 for demo scenario
  returnBufferMinutes: number;  // default: 30
}

export const DEFAULT_PREFERENCES: UserPreferences = {
  originCollegeId: 'itm-gwalior',
  budget: 600,
  travelMode: 'transit',
  arrivalBufferMinutes: 48, // Calibrated with the central demo scenario (leaves 5:40 AM, arrives 9:12 AM for 10:00 AM event with 3h 32m travel duration!)
  returnBufferMinutes: 30,
};
