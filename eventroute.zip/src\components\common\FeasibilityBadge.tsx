import React from 'react';
import { FeasibilityVerdict } from '../../types/feasibility';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

interface FeasibilityBadgeProps {
  verdict: FeasibilityVerdict;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const FeasibilityBadge: React.FC<FeasibilityBadgeProps> = ({
  verdict,
  size = 'md',
  showIcon = true,
}) => {
  const configs = {
    FEASIBLE: {
      label: 'FEASIBLE',
      bg: 'bg-emerald-50 border-emerald-200 text-emerald-700',
      dot: 'bg-emerald-500',
      icon: CheckCircle2,
      subtext: 'High feasibility to attend',
    },
    DIFFICULT: {
      label: 'DIFFICULT',
      bg: 'bg-amber-50 border-amber-200 text-amber-700',
      dot: 'bg-amber-500',
      icon: AlertTriangle,
      subtext: 'Requires tight schedule / high cost',
    },
    NOT_FEASIBLE: {
      label: 'NOT FEASIBLE',
      bg: 'bg-rose-50 border-rose-200 text-rose-700',
      dot: 'bg-rose-500',
      icon: XCircle,
      subtext: 'Timing conflict or no return',
    },
  };

  const config = configs[verdict] || configs.FEASIBLE;
  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1 font-semibold',
    md: 'text-xs px-2.5 py-1 gap-1.5 font-bold tracking-wide',
    lg: 'text-sm px-3.5 py-1.5 gap-2 font-bold tracking-wider',
  };

  const iconSizes = {
    sm: 12,
    md: 14,
    lg: 18,
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border shadow-xs transition-all ${config.bg} ${sizeClasses[size]}`}
    >
      {showIcon && <Icon size={iconSizes[size]} className="shrink-0" />}
      <span>{config.label}</span>
    </span>
  );
};
