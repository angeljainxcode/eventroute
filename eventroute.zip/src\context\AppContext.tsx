import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { CollegeEvent, EventCategory } from '../types/event';
import { CollegeOrigin } from '../types/location';
import { UserPreferences, DEFAULT_PREFERENCES } from '../types/userPreferences';
import { FeasibilityResult, FeasibilityVerdict } from '../types/feasibility';
import { COLLEGES, DEFAULT_COLLEGE } from '../data/colleges';
import { getAllEvents, publishEvent, getSavedEventIds, toggleSavedEvent } from '../services/storageService';
import { calculateFeasibility } from '../services/feasibilityEngine';

export type SortOption = 'soonest' | 'nearest' | 'lowest_cost' | 'most_feasible';

interface AppContextType {
  events: CollegeEvent[];
  origin: CollegeOrigin;
  preferences: UserPreferences;
  savedEventIds: string[];
  searchQuery: string;
  categoryFilter: EventCategory | 'all';
  feasibilityFilter: FeasibilityVerdict | 'all';
  maxDistanceFilter: number;
  sortOption: SortOption;
  isLoading: boolean;
  dataSource: 'supabase' | 'local_demo';
  
  // Actions
  setOrigin: (origin: CollegeOrigin) => void;
  updatePreferences: (partial: Partial<UserPreferences>) => void;
  setSearchQuery: (query: string) => void;
  setCategoryFilter: (category: EventCategory | 'all') => void;
  setFeasibilityFilter: (filter: FeasibilityVerdict | 'all') => void;
  setMaxDistanceFilter: (dist: number) => void;
  setSortOption: (sort: SortOption) => void;
  toggleSave: (eventId: string) => void;
  addNewEvent: (eventData: Omit<CollegeEvent, 'id' | 'isDemo' | 'verificationStatus' | 'lastVerified'>) => Promise<CollegeEvent>;
  getFeasibility: (event: CollegeEvent) => FeasibilityResult;
  refreshEvents: () => Promise<void>;
  resetFilters: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [events, setEvents] = useState<CollegeEvent[]>([]);
  const [origin, setOrigin] = useState<CollegeOrigin>(DEFAULT_COLLEGE);
  const [preferences, setPreferences] = useState<UserPreferences>(DEFAULT_PREFERENCES);
  const [savedEventIds, setSavedEventIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [dataSource, setDataSource] = useState<'supabase' | 'local_demo'>('local_demo');

  // Search & filter states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<EventCategory | 'all'>('all');
  const [feasibilityFilter, setFeasibilityFilter] = useState<FeasibilityVerdict | 'all'>('all');
  const [maxDistanceFilter, setMaxDistanceFilter] = useState<number>(500);
  const [sortOption, setSortOption] = useState<SortOption>('soonest');

  // Load initial data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const { events: loadedEvents, source } = await getAllEvents();
      setEvents(loadedEvents);
      setDataSource(source);
      setSavedEventIds(getSavedEventIds());
    } catch (err) {
      console.error('Failed to load events', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const updatePreferences = (partial: Partial<UserPreferences>) => {
    setPreferences(prev => ({ ...prev, ...partial }));
  };

  const toggleSave = (eventId: string) => {
    const { allSavedIds } = toggleSavedEvent(eventId);
    setSavedEventIds(allSavedIds);
  };

  const addNewEvent = async (
    eventData: Omit<CollegeEvent, 'id' | 'isDemo' | 'verificationStatus' | 'lastVerified'>
  ): Promise<CollegeEvent> => {
    const { event } = await publishEvent(eventData);
    setEvents(prev => [event, ...prev]);
    return event;
  };

  const getFeasibility = (event: CollegeEvent): FeasibilityResult => {
    return calculateFeasibility(event, origin, {
      arrivalBufferMinutes: preferences.arrivalBufferMinutes,
      postEventDepartureBufferMinutes: preferences.returnBufferMinutes,
      maxBudget: preferences.budget,
      travelMode: preferences.travelMode,
    });
  };

  const resetFilters = () => {
    setSearchQuery('');
    setCategoryFilter('all');
    setFeasibilityFilter('all');
    setMaxDistanceFilter(500);
    setSortOption('soonest');
  };

  return (
    <AppContext.Provider
      value={{
        events,
        origin,
        preferences,
        savedEventIds,
        searchQuery,
        categoryFilter,
        feasibilityFilter,
        maxDistanceFilter,
        sortOption,
        isLoading,
        dataSource,
        setOrigin,
        updatePreferences,
        setSearchQuery,
        setCategoryFilter,
        setFeasibilityFilter,
        setMaxDistanceFilter,
        setSortOption,
        toggleSave,
        addNewEvent,
        getFeasibility,
        refreshEvents: loadData,
        resetFilters,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
