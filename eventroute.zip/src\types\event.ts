import { Coordinates } from './location';

export type EventCategory = 
  | 'Hackathon' 
  | 'Technical Fest' 
  | 'Workshop' 
  | 'Symposium' 
  | 'Coding Contest' 
  | 'Robotics';

export interface TransitOption {
  type: 'bus' | 'train' | 'shared_cab';
  operator: string;
  departureTime: string; // "17:45"
  arrivalTime: string;   // "21:10"
  fare: number;          // in INR
  frequency: string;     // "Every 45 mins" or "Daily"
  originStation: string;
  destinationStation: string;
}

export interface CollegeEvent {
  id: string;
  title: string;
  hostCollege: string;
  venue: string;
  city: string;
  coordinates: Coordinates;
  date: string;              // "2026-10-24" (YYYY-MM-DD)
  startTime: string;         // "10:00" (24h)
  endTime: string;           // "17:00" (24h)
  category: EventCategory;
  description: string;
  registrationFee: number;   // 0 for free, in INR
  eligibility: string;       // "Open to all UG/PG students"
  registrationUrl: string;   // clearly demo
  bannerUrl: string;
  source: string;            // e.g. "College Tech Council Notice / Unstop Demo"
  lastVerified: string;      // ISO string
  isDemo: boolean;
  verificationStatus: 'verified_demo' | 'community_submitted' | 'official_partner';
  
  // Custom travel metrics for calibrated demonstration scenarios (fallback when not calculating dynamically)
  demoScenarioOverride?: {
    originCollegeId: string;
    distanceKm: number;
    travelDurationMinutes: number;
    oneWayCost: number;
    returnScheduleAvailable: boolean;
    returnOptions?: TransitOption[];
    notes?: string;
  };

  // Known scheduled return transit departures from venue/station back to Gwalior/origins
  returnTransitSchedule?: TransitOption[];
  hasConfirmedReturnSchedule?: boolean;
}
