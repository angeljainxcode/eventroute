import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { CollegeEvent } from '../../types/event';
import { CollegeOrigin } from '../../types/location';
import { FeasibilityResult } from '../../types/feasibility';

interface EventMapProps {
  events: CollegeEvent[];
  origin: CollegeOrigin;
  selectedEventId?: string;
  onSelectEvent: (event: CollegeEvent) => void;
  getFeasibility: (event: CollegeEvent) => FeasibilityResult;
}

export const EventMap: React.FC<EventMapProps> = ({
  events,
  origin,
  selectedEventId,
  onSelectEvent,
  getFeasibility,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // Initialize map once
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [origin.coordinates.lat, origin.coordinates.lng],
        zoom: 10,
        scrollWheelZoom: true,
      });

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        maxZoom: 19,
      }).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update markers when events or origin changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    const bounds = L.latLngBounds([]);

    // 1. Add Origin Marker
    const originIcon = L.divIcon({
      className: 'custom-origin-marker',
      html: `
        <div style="background-color: #026bc9; color: white; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(2,107,201,0.5); border: 3px solid #ffffff; font-weight: bold; font-size: 14px;">
          🏫
        </div>
      `,
      iconSize: [34, 34],
      iconAnchor: [17, 17],
      popupAnchor: [0, -18],
    });

    const originMarker = L.marker([origin.coordinates.lat, origin.coordinates.lng], {
      icon: originIcon,
      zIndexOffset: 1000,
    }).addTo(markersGroup);

    originMarker.bindPopup(`
      <div style="font-family: system-ui, sans-serif;">
        <span style="font-size: 10px; font-weight: 700; text-transform: uppercase; color: #026bc9; background: #e0effe; padding: 2px 6px; border-radius: 4px;">Your Starting Point</span>
        <h4 style="font-size: 13px; font-weight: 700; margin: 4px 0 2px; color: #0f172a;">${origin.name}</h4>
        <p style="font-size: 11px; color: #64748b; margin: 0;">${origin.city}, MP • ${origin.address}</p>
      </div>
    `);

    bounds.extend([origin.coordinates.lat, origin.coordinates.lng]);

    // 2. Add Event Markers
    events.forEach(event => {
      const feasibility = getFeasibility(event);
      const isSelected = selectedEventId === event.id;

      let color = '#16a34a'; // Feasible Green
      let badgeLabel = 'Feasible';
      let iconSymbol = '✓';

      if (feasibility.verdict === 'DIFFICULT') {
        color = '#d97706'; // Difficult Amber
        badgeLabel = 'Difficult';
        iconSymbol = '⚠';
      } else if (feasibility.verdict === 'NOT_FEASIBLE') {
        color = '#dc2626'; // Not Feasible Red
        badgeLabel = 'Infeasible';
        iconSymbol = '✕';
      }

      const markerHtml = `
        <div style="
          background-color: ${color}; 
          color: white; 
          width: ${isSelected ? '38px' : '30px'}; 
          height: ${isSelected ? '38px' : '30px'}; 
          border-radius: 50% 50% 50% 0; 
          transform: rotate(-45deg); 
          display: flex; 
          align-items: center; 
          justify-content: center; 
          box-shadow: 0 4px 12px rgba(0,0,0,0.3); 
          border: ${isSelected ? '3px solid #1e293b' : '2px solid #ffffff'}; 
          transition: all 0.2s;
        ">
          <span style="transform: rotate(45deg); font-size: ${isSelected ? '14px' : '11px'}; font-weight: 800;">
            ${iconSymbol}
          </span>
        </div>
      `;

      const eventIcon = L.divIcon({
        className: 'custom-event-marker',
        html: markerHtml,
        iconSize: [isSelected ? 38 : 30, isSelected ? 38 : 30],
        iconAnchor: [isSelected ? 19 : 15, isSelected ? 38 : 30],
        popupAnchor: [0, -32],
      });

      const marker = L.marker([event.coordinates.lat, event.coordinates.lng], {
        icon: eventIcon,
        zIndexOffset: isSelected ? 500 : 100,
      }).addTo(markersGroup);

      // Popup Content
      const popupHtml = `
        <div style="font-family: system-ui, sans-serif; min-width: 220px; max-width: 260px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
            <span style="font-size: 10px; font-weight: 700; color: white; background-color: ${color}; padding: 2px 8px; border-radius: 9999px;">
              ${feasibility.verdict}
            </span>
            <span style="font-size: 10px; font-weight: 600; color: #64748b;">${feasibility.distanceKm} km away</span>
          </div>

          <h4 style="font-size: 13px; font-weight: 700; margin: 6px 0 2px; color: #0f172a; line-height: 1.3;">
            ${event.title}
          </h4>
          <p style="font-size: 11px; color: #475569; margin: 0 0 6px;">
            ${event.hostCollege}
          </p>

          <div style="background-color: #f8fafc; padding: 6px 8px; border-radius: 8px; margin-bottom: 8px; font-size: 11px; border: 1px solid #e2e8f0;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
              <span style="color: #64748b;">Must Leave:</span>
              <strong style="color: #0f172a;">${feasibility.requiredDepartureTime}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #64748b;">Est. Roundtrip:</span>
              <strong style="color: #0f172a;">₹${feasibility.estimatedRoundTripCost}</strong>
            </div>
          </div>

          <button 
            id="map-btn-${event.id}"
            style="width: 100%; padding: 6px 10px; background-color: #026bc9; color: white; border: none; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.15s;"
          >
            Check Route & Feasibility →
          </button>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        onSelectEvent(event);
      });

      marker.on('popupopen', () => {
        const btn = document.getElementById(`map-btn-${event.id}`);
        if (btn) {
          btn.onclick = () => onSelectEvent(event);
        }
      });

      bounds.extend([event.coordinates.lat, event.coordinates.lng]);
    });

    if (events.length > 0) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13 });
    }
  }, [events, origin, selectedEventId]);

  return (
    <div className="relative w-full h-full min-h-[400px] rounded-2xl overflow-hidden shadow-sm border border-slate-200">
      <div ref={mapContainerRef} className="w-full h-full min-h-[400px] z-0" />
      
      {/* Legend Badge Overlay */}
      <div className="absolute top-3 right-3 z-10 bg-white/95 backdrop-blur-xs px-3 py-2 rounded-xl border border-slate-200 shadow-md text-[11px] flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span className="font-semibold text-slate-700">Feasible</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
          <span className="font-semibold text-slate-700">Difficult</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
          <span className="font-semibold text-slate-700">Infeasible</span>
        </div>
      </div>
    </div>
  );
};
