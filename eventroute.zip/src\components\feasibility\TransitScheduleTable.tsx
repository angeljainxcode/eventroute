import React from 'react';
import { TransitOption } from '../../types/event';
import { Bus, Train, Car, Clock, IndianRupee, ShieldCheck } from 'lucide-react';

interface TransitScheduleTableProps {
  options: TransitOption[];
  isConfirmed: boolean;
  eventEndTime: string;
}

export const TransitScheduleTable: React.FC<TransitScheduleTableProps> = ({
  options,
  isConfirmed,
  eventEndTime,
}) => {
  if (!options || options.length === 0) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-center text-xs text-slate-500">
        <p className="font-semibold text-slate-700">No scheduled return transit logged for this route.</p>
        <p className="mt-1">Students are advised to check local state bus stands or shared regional jeeps on ground.</p>
      </div>
    );
  }

  const getModeIcon = (type: TransitOption['type']) => {
    switch (type) {
      case 'train':
        return <Train size={14} className="text-indigo-600" />;
      case 'shared_cab':
        return <Car size={14} className="text-amber-600" />;
      case 'bus':
      default:
        return <Bus size={14} className="text-emerald-600" />;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-brand-600" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
            {isConfirmed ? 'Confirmed Return Transit Schedule' : 'Unconfirmed / Reference Transit Schedule'}
          </h4>
        </div>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
          isConfirmed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
        }`}>
          {isConfirmed ? 'Verified Timetable' : 'Demo Reference'}
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50/50 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-100">
            <tr>
              <th className="py-2.5 px-4 font-semibold">Service</th>
              <th className="py-2.5 px-4 font-semibold">Departs Venue</th>
              <th className="py-2.5 px-4 font-semibold">Arrives Origin</th>
              <th className="py-2.5 px-4 font-semibold">Fare</th>
              <th className="py-2.5 px-4 font-semibold">Stations</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {options.map((opt, idx) => (
              <tr key={idx} className="hover:bg-slate-50/60 transition-colors">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded-md bg-slate-100">
                      {getModeIcon(opt.type)}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800">{opt.operator}</span>
                      <p className="text-[10px] text-slate-400 capitalize">{opt.frequency}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-4 font-mono font-bold text-slate-900">
                  {opt.departureTime}
                </td>
                <td className="py-3 px-4 font-mono text-slate-700">
                  {opt.arrivalTime}
                </td>
                <td className="py-3 px-4 font-semibold text-slate-800">
                  ₹{opt.fare}
                </td>
                <td className="py-3 px-4 text-[11px] text-slate-500 max-w-[200px] truncate">
                  {opt.originStation} → {opt.destinationStation}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
