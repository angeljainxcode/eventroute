import React from 'react';
import { Route, ShieldCheck, Heart, Info, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200/80 pt-10 pb-8 text-xs text-slate-500 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-100">
          <div className="space-y-1.5 max-w-md">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <div className="w-6 h-6 rounded-lg bg-brand-600 text-white flex items-center justify-center">
                <Route size={14} />
              </div>
              <span>EventRoute</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Feasibility-first inter-college event discovery. Helping college students discover hackathons, fests, and workshops they can actually attend without missing classes or getting stranded.
            </p>
          </div>

          {/* Privacy & Trust Disclaimer Box */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 max-w-lg text-[11px] space-y-1 text-slate-600">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <ShieldCheck size={14} className="text-brand-600" />
              <span>Trust & Safety Architecture</span>
            </div>
            <p>
              Travel times, road distances, and transit fares are estimated using open routing standards (OSRM & road heuristics) and verified timetable schedules. No background GPS tracking is enforced without manual consent.
            </p>
          </div>
        </div>

        {/* Bottom copyright & Region notice */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span>Demo Region: Gwalior & Central India (MP/UP)</span>
            <span>•</span>
            <span>Deterministic Business Logic Engine</span>
          </div>

          <div className="flex items-center gap-1">
            <span>Built for student innovators with</span>
            <Heart size={12} className="text-rose-500 fill-rose-500" />
            <span>by EventRoute Team</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
