import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CollegeEvent } from '../../types/event';
import { 
  extractEventFromPoster, 
  parseNaturalLanguageQuery, 
  isAiServiceConfigured, 
  ExtractedPosterData 
} from '../../services/aiService';
import { FeasibilityBadge } from '../common/FeasibilityBadge';
import { 
  Sparkles, 
  Upload, 
  Search, 
  Sliders, 
  X, 
  CheckCircle2, 
  ArrowRight, 
  Cpu, 
  AlertCircle,
  FileImage,
  RefreshCw,
  ExternalLink
} from 'lucide-react';

interface AiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectEvent: (event: CollegeEvent) => void;
  onCheckFeasibility: (event: CollegeEvent) => void;
  onImportToPublish?: (data: ExtractedPosterData) => void;
}

export const AiModal: React.FC<AiModalProps> = ({
  isOpen,
  onClose,
  onSelectEvent,
  onCheckFeasibility,
  onImportToPublish,
}) => {
  const { events, getFeasibility, origin, preferences } = useApp();
  const [activeTab, setActiveTab] = useState<'poster' | 'nl_search' | 'recommend'>('poster');

  // Tab 1: Poster OCR state
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [extractedData, setExtractedData] = useState<ExtractedPosterData | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<string>('robotics');

  // Tab 2: Natural Language Search state
  const [nlQuery, setNlQuery] = useState<string>(
    'Find technical events this Saturday that I can attend from Gwalior and return the same day under ₹500.'
  );
  const [nlResult, setNlResult] = useState<ReturnType<typeof parseNaturalLanguageQuery> | null>(null);

  // Tab 3: Personalized Recommender state
  const [selectedInterest, setSelectedInterest] = useState<string>('Hackathon');

  if (!isOpen) return null;

  const handleRunPosterExtraction = async (presetName: string) => {
    setIsExtracting(true);
    setExtractedData(null);
    try {
      const data = await extractEventFromPoster(presetName);
      setExtractedData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleRunNlSearch = (queryText?: string) => {
    const text = queryText || nlQuery;
    const result = parseNaturalLanguageQuery(text, events);
    setNlResult(result);
  };

  const recommendedEvents = events.filter(e => {
    if (selectedInterest && e.category !== selectedInterest) {
      return false;
    }
    return true;
  }).slice(0, 4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-100 w-full max-w-3xl overflow-hidden flex flex-col max-h-[92vh] animate-scaleUp"
        role="dialog"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-indigo-50/80 via-white to-blue-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-brand-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">AI Student Assistant</h2>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isAiServiceConfigured ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                }`}>
                  {isAiServiceConfigured ? 'Gemini Vision Online' : 'Graceful Mock OCR Fallback'}
                </span>
              </div>
              <p className="text-xs text-slate-500">Poster parsing, natural language intent search, & personalized recommendations</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-100 px-6 bg-slate-50/50">
          <button
            onClick={() => setActiveTab('poster')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'poster'
                ? 'border-brand-600 text-brand-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileImage size={14} />
            <span>Poster-to-Event OCR</span>
          </button>

          <button
            onClick={() => setActiveTab('nl_search')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'nl_search'
                ? 'border-brand-600 text-brand-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Search size={14} />
            <span>Natural-Language Query</span>
          </button>

          <button
            onClick={() => setActiveTab('recommend')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'recommend'
                ? 'border-brand-600 text-brand-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sliders size={14} />
            <span>Personalized Match</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto space-y-6">

          {/* TAB 1: POSTER EXTRACTION */}
          {activeTab === 'poster' && (
            <div className="space-y-5">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs font-bold text-slate-700 block mb-1">
                  Upload an Event Flyer or Choose a Demo Poster
                </span>
                <p className="text-xs text-slate-500 mb-4">
                  Extract event title, dates, timings, entry fees, and student eligibility automatically.
                </p>

                {/* Preset Poster Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    { id: 'robotics', label: 'RoboDrone Fest Flyer', desc: 'MITS Tech Society' },
                    { id: 'hackathon', label: 'DevSprint Hackathon', desc: 'ITM Idea Lab' },
                    { id: 'genai', label: 'GenAI & Cloud Poster', desc: 'Jiwaji University' },
                  ].map(preset => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedPreset(preset.id);
                        handleRunPosterExtraction(preset.id);
                      }}
                      className={`p-3 rounded-xl border text-left text-xs transition-all ${
                        selectedPreset === preset.id
                          ? 'border-brand-600 bg-brand-50 text-brand-900 font-semibold ring-1 ring-brand-500'
                          : 'border-slate-200 bg-white hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <div className="font-bold">{preset.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{preset.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Extraction State */}
              {isExtracting ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="w-10 h-10 rounded-full border-3 border-brand-200 border-t-brand-600 animate-spin mx-auto mb-3" />
                  <p className="text-xs font-bold text-slate-800">Analyzing poster layout & optical characters...</p>
                  <p className="text-[11px] text-slate-500 mt-1">Extracting venue, date, eligibility, and fee structure</p>
                </div>
              ) : extractedData ? (
                <div className="p-5 bg-white rounded-2xl border border-emerald-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
                      <CheckCircle2 size={16} />
                      <span>Extracted Parameters (Confidence: {(extractedData.confidence * 100).toFixed(0)}%)</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Engine: {extractedData.extractedFrom}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Title</span>
                      <strong className="text-slate-900">{extractedData.title}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Host College</span>
                      <strong className="text-slate-900">{extractedData.hostCollege}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Date & Timing</span>
                      <span className="text-slate-800 font-mono">{extractedData.date} ({extractedData.startTime} - {extractedData.endTime})</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Fee & Category</span>
                      <span className="text-slate-800">{extractedData.registrationFee === 0 ? 'Free' : `₹${extractedData.registrationFee}`} • {extractedData.category}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600">
                    <strong>Summary:</strong> {extractedData.rawSummary}
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {/* TAB 2: NATURAL LANGUAGE SEARCH */}
          {activeTab === 'nl_search' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Natural-Language Event Query
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={nlQuery}
                    onChange={e => setNlQuery(e.target.value)}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-hidden"
                  />
                  <button
                    onClick={() => handleRunNlSearch()}
                    className="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
                  >
                    <Search size={14} />
                    <span>Parse Query</span>
                  </button>
                </div>
              </div>

              {/* Example Query Suggestions */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] text-slate-400">Try:</span>
                {[
                  'Find technical events this Saturday that I can attend from Gwalior and return the same day under ₹500.',
                  'Free hackathons near Gwalior under ₹300 travel',
                  'Robotics competitions with return transit confirmed',
                ].map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setNlQuery(sample);
                      handleRunNlSearch(sample);
                    }}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    "{sample.slice(0, 38)}..."
                  </button>
                ))}
              </div>

              {/* NL Parse Breakdown */}
              {nlResult && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="text-xs font-bold text-brand-800 flex items-center gap-1.5">
                    <Sparkles size={14} className="text-brand-600" />
                    <span>{nlResult.explanation}</span>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Matching Feasible Events ({nlResult.matchedEvents.length})
                    </h4>
                    {nlResult.matchedEvents.map(event => {
                      const feasibility = getFeasibility(event);
                      return (
                        <div
                          key={event.id}
                          className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs"
                        >
                          <div>
                            <div className="font-bold text-slate-900">{event.title}</div>
                            <div className="text-[11px] text-slate-500">{event.hostCollege} • {feasibility.distanceKm} km</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
                            <button
                              onClick={() => {
                                onCheckFeasibility(event);
                                onClose();
                              }}
                              className="px-3 py-1 rounded-lg bg-brand-600 text-white font-bold text-xs"
                            >
                              Route
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PERSONALIZED RECOMMENDATIONS */}
          {activeTab === 'recommend' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-700 block">
                  Select Your Academic Interests & Technical Focus
                </span>
                <div className="flex flex-wrap gap-2">
                  {['Hackathon', 'Robotics', 'Workshop', 'Symposium', 'Coding Contest'].map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setSelectedInterest(tag)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        selectedInterest === tag
                          ? 'bg-brand-600 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Recommended for Student at {origin.shortName} (Budget: ₹{preferences.budget})
                </h4>

                {recommendedEvents.map(event => {
                  const feasibility = getFeasibility(event);
                  return (
                    <div
                      key={event.id}
                      className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-brand-300 transition-all shadow-xs flex items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <FeasibilityBadge verdict={feasibility.verdict} size="sm" />
                          <span className="text-[11px] font-semibold text-slate-400">{event.category}</span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-900">{event.title}</h4>
                        <p className="text-xs text-slate-500">
                          {event.hostCollege} • Must leave {feasibility.requiredDepartureTime}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          onCheckFeasibility(event);
                          onClose();
                        }}
                        className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors shrink-0"
                      >
                        Check Route
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            EventRoute AI Sandbox • Real-time Feasibility Engine
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
