import React from 'react';
import { useApp, SortOption } from '../../context/AppContext';
import { EventCategory } from '../../types/event';
import { FeasibilityVerdict } from '../../types/feasibility';
import { 
  Search, 
  Filter, 
  MapPin, 
  SlidersHorizontal, 
  Map, 
  List, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  X,
  Compass
} from 'lucide-react';

interface SearchFiltersProps {
  viewMode: 'list' | 'map' | 'split';
  onChangeViewMode: (mode: 'list' | 'map' | 'split') => void;
  onOpenLocationModal: () => void;
  totalResults: number;
}

export const SearchFilters: React.FC<SearchFiltersProps> = ({
  viewMode,
  onChangeViewMode,
  onOpenLocationModal,
  totalResults,
}) => {
  const {
    origin,
    preferences,
    searchQuery,
    setSearchQuery,
    categoryFilter,
    setCategoryFilter,
    feasibilityFilter,
    setFeasibilityFilter,
    maxDistanceFilter,
    setMaxDistanceFilter,
    sortOption,
    setSortOption,
    resetFilters,
  } = useApp();

  const categories: { id: EventCategory | 'all'; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'Hackathon', label: 'Hackathons' },
    { id: 'Symposium', label: 'Symposiums' },
    { id: 'Technical Fest', label: 'Technical Fests' },
    { id: 'Workshop', label: 'Workshops' },
    { id: 'Coding Contest', label: 'Coding Contests' },
    { id: 'Robotics', label: 'Robotics' },
  ];

  const feasibilityFilters: { id: FeasibilityVerdict | 'all'; label: string; icon?: React.FC<any>; color: string }[] = [
    { id: 'all', label: 'All Verdicts', color: 'text-slate-600' },
    { id: 'FEASIBLE', label: 'Feasible Only', icon: CheckCircle2, color: 'text-emerald-700' },
    { id: 'DIFFICULT', label: 'Difficult / Tight', icon: AlertTriangle, color: 'text-amber-700' },
    { id: 'NOT_FEASIBLE', label: 'Not Feasible', icon: XCircle, color: 'text-rose-700' },
  ];

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs p-5 space-y-4">
      {/* Top Search Input & Origin Trigger */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search events, colleges, topics (e.g. hackathon, robotics, MITS)..."
            className="w-full pl-11 pr-10 py-2.5 rounded-2xl border border-slate-200 bg-slate-50 text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-brand-500 transition-all placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X size={15} />
            </button>
          )}
        </div>

        {/* Starting Origin Quick Button */}
        <button
          type="button"
          onClick={onOpenLocationModal}
          className="inline-flex items-center justify-between gap-2 px-4 py-2.5 rounded-2xl border border-brand-200 bg-brand-50/70 hover:bg-brand-100/70 text-brand-900 transition-all shadow-xs text-xs font-semibold shrink-0"
        >
          <div className="flex items-center gap-2">
            <MapPin size={15} className="text-brand-600" />
            <div className="text-left">
              <span className="text-[10px] uppercase font-bold text-brand-700 block leading-tight">Starting From</span>
              <span className="font-bold text-slate-900">{origin.shortName}</span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-brand-700 bg-white/90 px-2 py-0.5 rounded-lg border border-brand-200 ml-1">
            ₹{preferences.budget}
          </span>
        </button>

        {/* Mobile / Desktop Map Toggle */}
        <div className="inline-flex p-1 bg-slate-100 rounded-2xl border border-slate-200 shrink-0 self-end md:self-auto">
          <button
            type="button"
            onClick={() => onChangeViewMode('split')}
            className={`hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              viewMode === 'split' ? 'bg-white text-brand-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Compass size={14} />
            <span>Split</span>
          </button>
          <button
            type="button"
            onClick={() => onChangeViewMode('list')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              viewMode === 'list' ? 'bg-white text-brand-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <List size={14} />
            <span>Cards</span>
          </button>
          <button
            type="button"
            onClick={() => onChangeViewMode('map')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              viewMode === 'map' ? 'bg-white text-brand-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Map size={14} />
            <span>Map</span>
          </button>
        </div>
      </div>

      {/* Categories Row */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5 no-scrollbar">
        {categories.map(cat => {
          const isSelected = categoryFilter === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-brand-600 text-white shadow-xs'
                  : 'bg-slate-100/80 text-slate-600 hover:bg-slate-200/80'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Feasibility Filter & Sorting Row */}
      <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Feasibility Verdict Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1">Feasibility:</span>
          {feasibilityFilters.map(f => {
            const isSelected = feasibilityFilter === f.id;
            const Icon = f.icon;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFeasibilityFilter(f.id)}
                className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'border-brand-600 bg-brand-50 text-brand-800 font-bold shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                {Icon && <Icon size={12} className={f.color} />}
                <span>{f.label}</span>
              </button>
            );
          })}
        </div>

        {/* Sort & Result count */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Sort:</span>
            <select
              value={sortOption}
              onChange={e => setSortOption(e.target.value as SortOption)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-brand-500"
            >
              <option value="soonest">Soonest Date</option>
              <option value="nearest">Nearest Distance</option>
              <option value="lowest_cost">Lowest Travel Cost</option>
              <option value="most_feasible">Most Feasible</option>
            </select>
          </div>

          <span className="text-[11px] text-slate-400 font-mono">
            {totalResults} events found
          </span>
        </div>

      </div>
    </div>
  );
};
